import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutGrid, Shirt, PlusCircle, Calendar as CalendarIcon, 
  UserCircle, Camera, Heart, RotateCw, Plus, X, 
  ChevronLeft, ChevronRight, Check, ArrowLeft, ArrowRight, Info, ChevronDown, ChevronUp
} from 'lucide-react';

// --- SVGs & DATA ---

const SILUETAS = {
  "Reloj de Arena": <path d="M20,10 Q30,40 20,70 Q30,70 20,70 Q10,70 20,70 Q10,40 20,10" fill="none" stroke="currentColor" strokeWidth="1.5"/>, // Placeholder simplified
  "Triángulo": <path d="M30,70 L20,30 L10,70 Z" fill="none" stroke="currentColor" strokeWidth="1.5"/>,
  "Triángulo Invertido": <path d="M10,30 L20,70 L30,30 Z" fill="none" stroke="currentColor" strokeWidth="1.5"/>,
  "Rectángulo": <rect x="15" y="20" width="10" height="50" fill="none" stroke="currentColor" strokeWidth="1.5"/>,
  "Óvalo": <ellipse cx="20" cy="45" rx="12" ry="25" fill="none" stroke="currentColor" strokeWidth="1.5"/>,
};

const FACE_SHAPES = {
  "Ovalada": <ellipse cx="20" cy="20" rx="10" ry="14" fill="none" stroke="currentColor" strokeWidth="1.5"/>,
  "Redonda": <circle cx="20" cy="20" r="12" fill="none" stroke="currentColor" strokeWidth="1.5"/>,
  "Cuadrada": <rect x="10" y="8" width="20" height="24" rx="4" fill="none" stroke="currentColor" strokeWidth="1.5"/>,
  "Corazón": <path d="M20,32 Q10,25 10,15 Q10,8 15,8 Q20,10 20,15 Q20,10 25,8 Q30,8 30,15 Q30,25 20,32" fill="none" stroke="currentColor" strokeWidth="1.5"/>,
  "Alargada": <ellipse cx="20" cy="20" rx="8" ry="16" fill="none" stroke="currentColor" strokeWidth="1.5"/>,
  "Diamante": <path d="M20,5 L32,20 L20,35 L8,20 Z" fill="none" stroke="currentColor" strokeWidth="1.5"/>,
};

const PALETAS = {
  Primavera: ["#FF6B6B", "#FFD93D", "#FFAB91", "#A8E6CF", "#FFF3E0", "#FF8A65", "#DCE775", "#FFCC80"],
  Otoño: ["#BF360C", "#F9A825", "#558B2F", "#880E4F", "#FFF8E1", "#6D4C41", "#E65100", "#827717"],
  Verano: ["#CE93D8", "#F48FB1", "#81D4FA", "#CFD8DC", "#80CBC4", "#B39DDB", "#EF9A9A", "#A5D6A7"],
  Invierno: ["#0A0A0A", "#FAFAFA", "#D32F2F", "#1565C0", "#00695C", "#6A1B9A", "#F50057", "#00838F"],
};

const ESTETICAS = [
  { name: "Minimal", desc: "Menos es más. Piezas clave, colores neutros.", gradient: "from-[#F0F0F0] to-[#E0E0E0]" },
  { name: "Streetwear", desc: "Oversized, gráficos, sneakers.", gradient: "from-[#E8E8E8] to-[#D0D0D0]" },
  { name: "Clásico", desc: "Atemporal. Blazers, camisas, piezas atemporales.", gradient: "from-[#F5F5F0] to-[#E8E8E0]" },
  { name: "Bohemio", desc: "Texturas, capas, estampados naturales.", gradient: "from-[#F0EDE8] to-[#E5E0D8]" },
  { name: "Sport Luxe", desc: "Athleisure elevado. Funcional y estético.", gradient: "from-[#E5E8E8] to-[#D8DCDC]" },
  { name: "Vanguardia", desc: "Experimental, oversized, deconstruido.", gradient: "from-[#E0E0E5] to-[#D0D0D8]" },
];

const GARMENTS = [
  {
    id: 1, name: "Camisa Oxford Blanca", category: "Tops",
    mainColor: "#F8F8F8", bgColor: "#F0EDE8",
    dots: ["#F8F8F8", "#E8E8E8"],
    material: "Algodón", pattern: "Liso", formality: 4,
    seasons: ["Primavera", "Verano", "Otoño", "Invierno"],
    uses: 18, lastWorn: "Hace 3 días", daysAgo: 3,
    outfitsWith: ["of-1", "ev-2"]
  },
  {
    id: 2, name: "Camiseta Negra Básica", category: "Tops",
    mainColor: "#1A1A1A", bgColor: "#E8E8E8",
    dots: ["#1A1A1A", "#2A2A2A"],
    material: "Algodón", pattern: "Liso", formality: 2,
    seasons: ["Primavera", "Verano", "Otoño", "Invierno"],
    uses: 32, lastWorn: "Ayer", daysAgo: 1,
    outfitsWith: ["ca-1", "of-3"]
  },
  {
    id: 3, name: "Blazer Gris Oversize", category: "Outer",
    mainColor: "#6B6B6B", bgColor: "#E5E5E5",
    dots: ["#6B6B6B", "#8A8A8A"],
    material: "Lana", pattern: "Liso", formality: 4,
    seasons: ["Otoño", "Invierno"],
    uses: 8, lastWorn: "Hace 5 días", daysAgo: 5,
    outfitsWith: ["of-1", "ca-3", "ev-1"]
  },
  {
    id: 4, name: "Jeans Slim Oscuros", category: "Bottoms",
    mainColor: "#2C3E6B", bgColor: "#D8DEE8",
    dots: ["#2C3E6B", "#1A2744"],
    material: "Denim", pattern: "Liso", formality: 2,
    seasons: ["Primavera", "Verano", "Otoño", "Invierno"],
    uses: 25, lastWorn: "Hoy", daysAgo: 0,
    outfitsWith: ["of-3", "ca-1", "ca-3"]
  },
  {
    id: 5, name: "Chino Beige", category: "Bottoms",
    mainColor: "#D4C5A9", bgColor: "#EDE8DF",
    dots: ["#D4C5A9", "#BFB08A"],
    material: "Algodón", pattern: "Liso", formality: 3,
    seasons: ["Primavera", "Verano"],
    uses: 14, lastWorn: "Hace 4 días", daysAgo: 4,
    outfitsWith: ["of-2"]
  },
  {
    id: 6, name: "Falda Midi Plisada", category: "Bottoms",
    mainColor: "#1A1A1A", bgColor: "#E0E0E0",
    dots: ["#1A1A1A"],
    material: "Poliéster", pattern: "Plisado", formality: 4,
    seasons: ["Otoño", "Invierno"],
    uses: 6, lastWorn: "Hace 32 días", daysAgo: 32,
    outfitsWith: ["of-1", "ci-1", "ci-2", "ev-2"]
  },
  {
    id: 7, name: "Sneakers Blancos", category: "Calzado",
    mainColor: "#F5F5F5", bgColor: "#EAEAEA",
    dots: ["#F5F5F5", "#E0E0E0"],
    material: "Cuero", pattern: "Liso", formality: 1,
    seasons: ["Primavera", "Verano", "Otoño", "Invierno"],
    uses: 30, lastWorn: "Hoy", daysAgo: 0,
    outfitsWith: ["ca-1", "ca-2"]
  },
  {
    id: 8, name: "Botines Chelsea", category: "Calzado",
    mainColor: "#1A1A1A", bgColor: "#E0E0E0",
    dots: ["#1A1A1A", "#3A3A3A"],
    material: "Cuero", pattern: "Liso", formality: 4,
    seasons: ["Otoño", "Invierno"],
    uses: 12, lastWorn: "Hace 2 días", daysAgo: 2,
    outfitsWith: ["of-1", "ci-1", "ci-2", "ev-1"]
  },
  {
    id: 9, name: "Suéter Crema Cuello Alto", category: "Tops",
    mainColor: "#F5E6D3", bgColor: "#F0EBE3",
    dots: ["#F5E6D3", "#E8D5BE"],
    material: "Cashmere", pattern: "Liso", formality: 3,
    seasons: ["Otoño", "Invierno"],
    uses: 9, lastWorn: "Hace 6 días", daysAgo: 6,
    outfitsWith: ["of-2", "ca-3", "ci-1"]
  },
  {
    id: 10, name: "Vestido Camisero Oliva", category: "Tops",
    mainColor: "#558B2F", bgColor: "#E4EBD8",
    dots: ["#558B2F", "#6B9B3F"],
    material: "Lino", pattern: "Liso", formality: 3,
    seasons: ["Primavera", "Verano"],
    uses: 4, lastWorn: "Hace 34 días", daysAgo: 34,
    outfitsWith: ["ca-2", "ev-1"]
  },
  {
    id: 11, name: "Bufanda Gris Jaspeada", category: "Accesorios",
    mainColor: "#9E9E9E", bgColor: "#EAEAEA",
    dots: ["#9E9E9E", "#B0B0B0", "#808080"],
    material: "Lana", pattern: "Jaspeado", formality: 2,
    seasons: ["Otoño", "Invierno"],
    uses: 5, lastWorn: "Hace 41 días", daysAgo: 41,
    outfitsWith: ["ca-3"]
  },
  {
    id: 12, name: "Bolso Tote Negro", category: "Accesorios",
    mainColor: "#2A2A2A", bgColor: "#E0E0E0",
    dots: ["#2A2A2A", "#1A1A1A"],
    material: "Cuero", pattern: "Liso", formality: 3,
    seasons: ["Primavera", "Verano", "Otoño", "Invierno"],
    uses: 22, lastWorn: "Ayer", daysAgo: 1,
    outfitsWith: ["of-1", "of-2", "ca-2"]
  }
];

const OUTFITS_BY_OCCASION = {
  "Oficina": [
    { 
      id: "of-1", 
      name: "Power Meeting", 
      occasion: "Oficina", 
      colors: ["#FFFFFF", "#1A1A1A", "#1A1A1A", "#6B6B6B"],
      bodyTip: "Falda midi + blazer entallado: silueta profesional que respeta tu curva natural de reloj de arena",
      colorTip: "Negro + blanco + gris: base neutra ejecutiva — añade un accesorio en terracota para calidez"
    },
    { 
      id: "of-2", 
      name: "Smart Friday", 
      occasion: "Oficina", 
      colors: ["#F5E6D3", "#D4C5A9", "#F5F5F5"],
      bodyTip: "El suéter cuello alto define tu torso, el chino recto equilibra la cadera — proporción perfecta",
      colorTip: "Full paleta Otoño: crema y beige son tus colores estrella del día a día"
    },
    { 
      id: "of-3", 
      name: "Directora Creativa", 
      occasion: "Oficina", 
      colors: ["#1A1A1A", "#2C3E6B", "#1A1A1A", "#6B6B6B"],
      bodyTip: "Jeans slim + blazer: marca cintura natural sin esfuerzo. El blazer oversize crea drama arriba",
      colorTip: "Base total oscura — rompe con un labial terracota o bufanda mostaza"
    },
    { 
      id: "of-4", 
      name: "Oficina sin Corbata", 
      occasion: "Oficina", 
      colors: ["#F8F8F8", "#D4C5A9", "#1A1A1A"],
      bodyTip: "Camisa oxford + chino beige: sencillez profesional y cómoda para días de foco",
      colorTip: "Tonos tierra suaves que armonizan con tu subtono cálido otoñal"
    }
  ],
  "Casual": [
    { 
      id: "ca-1", 
      name: "Domingo Relax", 
      occasion: "Casual", 
      colors: ["#1A1A1A", "#2C3E6B", "#F5F5F5"],
      bodyTip: "Camiseta + jeans slim: lo básico que nunca falla para tu silueta reloj de arena",
      colorTip: "Negro + blanco: base neutra que puedes elevar con accesorios en mostaza o terracota"
    },
    { 
      id: "ca-2", 
      name: "Lino & Relax", 
      occasion: "Casual", 
      colors: ["#558B2F", "#558B2F", "#F5F5F5"],
      bodyTip: "El vestido camisero crea cintura definida sin esfuerzo — agrega un cinturón para más definición",
      colorTip: "Oliva es clave en tu paleta Otoño — combínalo con accesorios en chocolate y crema"
    },
    { 
      id: "ca-3", 
      name: "Capas de Otoño", 
      occasion: "Casual", 
      colors: ["#F5E6D3", "#2C3E6B", "#F5F5F5", "#6B6B6B"],
      bodyTip: "Capas estructuradas sin ocultar tu silueta — el blazer da forma, la bufanda da volumen arriba",
      colorTip: "Crema + gris: combinación otoñal sofisticada que armoniza con tu subtono cálido"
    },
    { 
      id: "ca-4", 
      name: "Monocromo Urbano", 
      occasion: "Casual", 
      colors: ["#1A1A1A", "#2C3E6B", "#F5F5F5"],
      bodyTip: "Camiseta negra + jeans slim oscuros: contraste que estiliza y aporta un aire minimalista",
      colorTip: "La base oscura es ideal para resaltar tus rasgos otoñales con un pop de color"
    }
  ],
  "Cita": [
    { 
      id: "ci-1", 
      name: "Minimal Chic", 
      occasion: "Cita", 
      colors: ["#F5E6D3", "#1A1A1A", "#1A1A1A"],
      bodyTip: "La falda midi aporta movimiento y feminidad. El suéter cuello alto equilibra la proporción arriba",
      colorTip: "Crema + negro: contraste elegante con base otoñal — labios en terracota completarían el look"
    },
    { 
      id: "ci-2", 
      name: "Noche Elegante", 
      occasion: "Cita", 
      colors: ["#1A1A1A", "#1A1A1A", "#1A1A1A", "#6B6B6B"],
      bodyTip: "Blazer + falda midi: silueta dramática que alarga tu cuerpo y define la cintura",
      colorTip: "Total look oscuro con texturas — añade aretes dorados para calidez otoñal"
    }
  ],
  "Evento": [
    { 
      id: "ev-1", 
      name: "Cocktail Otoñal", 
      occasion: "Evento", 
      colors: ["#558B2F", "#1A1A1A", "#1A1A1A", "#6B6B6B"],
      bodyTip: "Vestido + blazer estructurado: combo perfecto para eventos semi-formales en tu silueta",
      colorTip: "Oliva profundo es statement puro en tu paleta Otoño — destaca sin gritar"
    },
    { 
      id: "ev-2", 
      name: "Gala Minimal", 
      occasion: "Evento", 
      colors: ["#FFFFFF", "#1A1A1A", "#1A1A1A"],
      bodyTip: "Camisa entallada + falda midi: proporciones clásicas que honran tu reloj de arena",
      colorTip: "Blanco + negro con textura: elegancia atemporal. Añade un clutch en burdeos"
    }
  ]
};

const OUTFITS_DATA = [
  ...OUTFITS_BY_OCCASION["Oficina"],
  ...OUTFITS_BY_OCCASION["Casual"],
  ...OUTFITS_BY_OCCASION["Cita"],
  ...OUTFITS_BY_OCCASION["Evento"]
];

const MAKEUP_LOOKS = [
  {
    name: "Otoño Natural",
    vibe: "Día a día",
    steps: [
      { area: "BASE", desc: "BB Cream tono cálido medio", color: "#D4A574" },
      { area: "OJOS", desc: "Sombra marrón dorado + delineado", color: "#8B6914" },
      { area: "LABIOS", desc: "Terracota mate", color: "#BF360C" },
      { area: "MEJILLAS", desc: "Blush melocotón suave", color: "#FFAB91" },
    ],
    tip: "Para tu rostro ovalado: aplica el blush en las manzanas de las mejillas difuminando hacia las sienes. Tu proporción equilibrada permite blush generoso sin preocuparte por ensanchar."
  },
  {
    name: "Power Glam",
    vibe: "Noche",
    steps: [
      { area: "BASE", desc: "Base luminosa alta cobertura", color: "#D4A574" },
      { area: "OJOS", desc: "Smokey en burdeos + máscara", color: "#880E4F" },
      { area: "LABIOS", desc: "Burdeos cremoso", color: "#880E4F" },
      { area: "MEJILLAS", desc: "Contorno bronce + highlight", color: "#F9A825" },
    ],
    tip: "Tu rostro ovalado permite smokey eyes intenso sin preocuparte por el equilibrio — ya lo tienes naturalmente. El burdeos es perfecto para tu paleta Otoño."
  },
  {
    name: "Glow Minimal",
    vibe: "Oficina",
    steps: [
      { area: "BASE", desc: "Tinted moisturizer con SPF", color: "#D4A574" },
      { area: "OJOS", desc: "Máscara marrón + cejas peinadas", color: "#6D4C41" },
      { area: "LABIOS", desc: "Lip oil en miel", color: "#E65100" },
      { area: "MEJILLAS", desc: "Cream blush cálido", color: "#FFAB91" },
    ],
    tip: "Tu subtono cálido brilla con menos producto — deja que tu piel hable. El lip oil en miel potencia el dorado natural de tu tono."
  }
];

const HAIRSTYLES = [
  { id: 1, name: "Ondas Sueltas", occasion: "Casual", icon: "〰️", desc: "Ondas naturales desde el medio del cabello. Raya al centro o ligeramente lateral.", tip: "Ideal para cara ovalada: las ondas no necesitan compensar nada, solo enmarcan tu rostro de manera natural." },
  { id: 2, name: "Cola Baja Elegante", occasion: "Oficina", icon: "◎", desc: "Cola baja con raya al medio, mechones sueltos enmarcando el rostro.", tip: "Alarga sutilmente tu rostro ovalado — perfecto para meetings. Los mechones sueltos suavizan." },
  { id: 3, name: "Moño Relajado", occasion: "Cita", icon: "●", desc: "Moño bajo, ligeramente despeinado, con mechones al frente.", tip: "Despeja tu cara ovalada y resalta tu jawline — súper elegante sin esfuerzo." },
  { id: 4, name: "Liso con Volumen", occasion: "Evento", icon: "▽", desc: "Brushing con volumen en la raíz, puntas hacia adentro.", tip: "El volumen en la raíz añade drama sin desequilibrar tus proporciones ovaladas." },
  { id: 5, name: "Trenza Lateral", occasion: "Casual", icon: "⟡", desc: "Trenza lateral suelta, empezando desde la sien. Textura bohemia.", tip: "La asimetría juega bien con caras ovaladas — añade interés visual sin desequilibrar." }
];

// --- COMPONENTS ---

const IconButton = ({ icon: Icon, onClick, className = "", size = 20 }: any) => (
  <button onClick={onClick} className={`p-2 active:scale-95 flex items-center justify-center rounded-full ${className}`}>
    <Icon size={size} strokeWidth={2} />
  </button>
);

const StepHeader = ({ step, onBack }: { step: number, onBack?: () => void }) => {
  return (
    <div className="px-6 pt-12 pb-4 shrink-0">
      <div className="flex items-center justify-between mb-6 h-8">
        {step > 1 ? (
          <IconButton icon={ArrowLeft} onClick={onBack} className="bg-white/50 -ml-2" />
        ) : <div />}
        <div className="flex gap-1.5 flex-1 justify-center max-w-[150px]">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className={`h-1 flex-1 rounded-full ${i < step ? 'bg-estela-black' : 'bg-[#E5E5E5]'}`} />
          ))}
        </div>
        <div className="w-8" />
      </div>
    </div>
  );
};

const BodyShapeSVG = ({ type }: { type: string }) => (
  <svg viewBox="0 0 40 80" className="w-full h-full text-estela-black opacity-80">
    {type === "Reloj de Arena" && <path d="M10,10 C20,10 20,10 30,10 C25,35 25,45 30,75 C20,75 20,75 10,75 C15,45 15,35 10,10" fill="none" stroke="currentColor" strokeWidth="1.5"/>}
    {type === "Triángulo" && <path d="M20,10 L35,75 L5,75 Z" fill="none" stroke="currentColor" strokeWidth="1.5"/>}
    {type === "Triángulo Invertido" && <path d="M5,10 L35,10 L20,75 Z" fill="none" stroke="currentColor" strokeWidth="1.5"/>}
    {type === "Rectángulo" && <rect x="8" y="10" width="24" height="65" fill="none" stroke="currentColor" strokeWidth="1.5"/>}
    {type === "Óvalo" && <ellipse cx="20" cy="42.5" rx="14" ry="32.5" fill="none" stroke="currentColor" strokeWidth="1.5"/>}
    {type === "No estoy seguro/a" && <text x="20" y="45" textAnchor="middle" fontSize="16">?</text>}
  </svg>
);

const FaceShapeSVG = ({ type }: { type: string }) => (
  <svg viewBox="0 0 40 40" className="w-full h-full text-estela-black opacity-80">
    {type === "Ovalada" && <ellipse cx="20" cy="20" rx="10" ry="14" fill="none" stroke="currentColor" strokeWidth="1.5"/>}
    {type === "Redonda" && <circle cx="20" cy="20" r="12" fill="none" stroke="currentColor" strokeWidth="1.5"/>}
    {type === "Cuadrada" && <rect x="10" y="8" width="20" height="24" rx="4" fill="none" stroke="currentColor" strokeWidth="1.5"/>}
    {type === "Corazón" && <path d="M20,32 C12,24 8,20 8,14 C8,10 12,8 16,8 C18,8 20,10 20,10 C20,10 22,8 24,8 C28,8 32,10 32,14 C32,20 28,24 20,32" fill="none" stroke="currentColor" strokeWidth="1.5"/>}
    {type === "Alargada" && <ellipse cx="20" cy="20" rx="8" ry="16" fill="none" stroke="currentColor" strokeWidth="1.5"/>}
    {type === "Diamante" && <path d="M20,6 L30,20 L20,34 L10,20 Z" fill="none" stroke="currentColor" strokeWidth="1.5"/>}
  </svg>
);

// --- MAIN APP COMPONENT ---

export default function App() {
  const [step, setStep] = useState(1);
  const [showReveal, setShowReveal] = useState(false);
  const [activeScreen, setActiveScreen] = useState("home");
  const [activeFilter, setActiveFilter] = useState("Todo");
  const [expandedOutfitId, setExpandedOutfitId] = useState<string | null>(null);
  const [expandedHairId, setExpandedHairId] = useState<number | null>(null);
  const [expandedMakeupId, setExpandedMakeupId] = useState<string | null>(null);

  // Closet State
  const [activeClosetCategory, setActiveClosetCategory] = useState("Todo");
  const [closetSort, setClosetSort] = useState("Recientes");
  const [selectedGarment, setSelectedGarment] = useState<any | null>(null);
  const [isGarmentModalOpen, setIsGarmentModalOpen] = useState(false);

  // Add Garment State
  const [addGarmentStep, setAddGarmentStep] = useState(1);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showAnalysisResult, setShowAnalysisResult] = useState(false);
  const [shutterEffect, setShutterEffect] = useState(false);

  
  const carouselRef = useRef<HTMLDivElement>(null);
  const touchStartX = useRef(0);

  const filteredOutfits = useMemo(() => {
    if (activeFilter === "Todo") {
      return [
        OUTFITS_BY_OCCASION["Oficina"][0],
        OUTFITS_BY_OCCASION["Casual"][0],
        OUTFITS_BY_OCCASION["Cita"][0],
        OUTFITS_BY_OCCASION["Evento"][0]
      ];
    }
    return OUTFITS_BY_OCCASION[activeFilter as keyof typeof OUTFITS_BY_OCCASION] || [];
  }, [activeFilter]);

  const handleFilterChange = (f: string) => {
    setActiveFilter(f);
    if (carouselRef.current) {
      carouselRef.current.scrollTo({ left: 0, behavior: 'smooth' });
    }
  };

  // User Profile State
  const [user, setUser] = useState({
    name: "Valentina",
    gender: "Femenino",
    height: 165,
    weight: 0,
    includeWeight: false,
    size: "M",
    bodyType: "Reloj de Arena",
    faceShape: "Ovalada",
    skinTone: "Cálido",
    station: "Otoño",
    estilos: ["Minimal", "Clásico"],
    itemsCount: 0
  });

  // Analysis State
  const [analysis, setAnalysis] = useState<{ active: boolean, type: 'body' | 'face', step: 'camera' | 'processing' | 'result', result: string | null }>({
    active: false,
    type: 'body',
    step: 'camera',
    result: null
  });

  // Calendar State
  const [activeCalendarView, setActiveCalendarView] = useState<'monthly' | 'daily'>('monthly');
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<number>(28);
  const [agendaLog, setAgendaLog] = useState({
    3: { slots: { morning: 'ca-1', afternoon: 'ca-1' } },
    4: { slots: { morning: 'of-2' } },
    6: { slots: { morning: 'ca-3' } },
    8: { slots: { morning: 'of-1' } },
    9: { slots: {} },
    10: { slots: { morning: 'of-3' } },
    11: { slots: { morning: 'of-2', night: 'ci-1' } },
    12: { slots: { morning: 'ca-2' } },
    15: { slots: { morning: 'ca-4' } },
    16: { slots: { morning: 'of-4' } },
    17: { slots: { morning: 'of-1' } },
    18: { slots: { morning: 'ca-1', night: 'ci-2' } },
    19: { slots: { morning: 'ca-3' } },
    20: { slots: { morning: 'ev-1' } },
    22: { slots: { morning: 'of-4', night: 'ci-1' } },
    23: { slots: { morning: 'of-3' } },
    24: { slots: { morning: 'ca-4' } },
    25: { slots: { morning: 'ca-1' } },
    28: { slots: { morning: 'of-1' } }
  });

  const startAnalysis = (type: 'body' | 'face') => {
    setAnalysis({ active: true, type, step: 'camera', result: null });
  };

  const captureAnalysis = () => {
    setAnalysis(p => ({ ...p, step: 'processing' }));
    setTimeout(() => {
      const type = analysis.type;
      const result = type === 'body' ? 'Reloj de Arena' : 'Ovalada'; // Mock detection
      setAnalysis(p => ({ ...p, step: 'result', result }));
      setUser(u => ({ ...u, [type === 'body' ? 'bodyType' : 'faceShape']: result }));
    }, 2500);
  };

  const closeAnalysis = () => setAnalysis({ active: false, type: 'body', step: 'camera', result: null });

  const goNext = () => setStep(s => s + 1);
  const goBack = () => setStep(s => s - 1);

  // --- SUB-RENDER SCREENS ---

  const renderHomeScreen = () => (
    <div className="flex-1 flex flex-col">
      {/* 1. Header */}
      <header className="px-6 pt-10 pb-4">
        <h1 className="serif text-[24px]">Buenos días, Valentina</h1>
        <p className="text-[13px] text-estela-light-gray">☁ 18°C · Bogotá</p>
      </header>

      {/* 2. DNA Badge */}
      <div className="px-6 mb-6">
        <div className="bg-[#F5F5F5] rounded-[14px] p-3.5 flex items-center justify-between border border-black/5">
          <div className="flex items-center gap-3">
            <div className="w-8 h-10 bg-white rounded-md p-1.5 shadow-sm"><BodyShapeSVG type={user.bodyType} /></div>
            <div className="flex gap-1">
              {PALETAS[user.station as keyof typeof PALETAS].slice(0,3).map(c => <div key={c} className="w-2.5 h-2.5 rounded-full" style={{ background: c }} />)}
            </div>
            <span className="mono text-[11px] font-bold border-l border-black/10 pl-3">
              {user.station} · {user.estilos.join(' & ')} · {user.bodyType}
            </span>
          </div>
          <IconButton icon={RotateCw} size={14} className="bg-white shadow-sm" />
        </div>
      </div>

      {/* 3. Filtros Pills */}
      <div className="scroll-hide flex gap-2 px-6 mb-6">
        {["Todo", "Oficina", "Casual", "Cita", "Evento"].map((f) => {
          const isActive = activeFilter === f;
          return (
            <button 
              key={f} 
              onClick={() => handleFilterChange(f)}
              className={`px-5 py-2 rounded-20px text-[13px] font-medium transition-all shrink-0 ${isActive ? 'bg-[#0A0A0A] text-white' : 'bg-white border-[1.5px] border-[#DCDCDC] text-[#555]'}`}
            >
              {f}
            </button>
          );
        })}
      </div>

      {/* 4. Carrusel de Outfits */}
      <div ref={carouselRef} className="snap-container flex gap-3 px-6 pb-2 min-h-[460px]">
        <AnimatePresence mode="popLayout">
          {filteredOutfits.map((o, idx) => {
            const isExpanded = expandedOutfitId === o.id;
            return (
              <motion.div 
                key={`${activeFilter}-${o.id}`}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ delay: idx * 0.08, duration: 0.3 }}
                onClick={() => setExpandedOutfitId(isExpanded ? null : o.id)}
                className="snap-item w-[82vw] max-w-[320px] bg-white rounded-16px shadow-lg p-3.5 relative border border-black/5 self-start cursor-pointer transition-shadow hover:shadow-xl"
              >
                {/* Grid de prendas */}
                <div className="grid grid-cols-2 gap-1.5 aspect-square mb-4">
                  {o.colors.map((c, i) => {
                    let bgColor = '#F5E6E0'; // default
                    if (c === '#1A2B3C' || c === '#2C3E6B') bgColor = '#E0E8F0'; // jeans/denim
                    if (c === '#558B2F') bgColor = '#E4EBD8'; // oliva
                    if (c === '#0A0A0A' || c === '#707070' || c === '#8E8E8E' || c === '#1A1A1A') bgColor = '#F0F0F0';
                    if (c === '#FFF8E1' || c === '#EAD8C0' || c === '#F5E6D3') bgColor = '#EDE8DF';
                    
                    return (
                      <div key={i} className="rounded-12px flex items-center justify-center p-3" style={{ background: bgColor }}>
                        <div className="w-full h-full rounded-8px shadow-sm" style={{ background: c }} />
                      </div>
                    );
                  })}
                </div>

                {/* Botones flotantes */}
                <div className="absolute top-5 right-5 flex flex-col gap-2 z-20" onClick={e => e.stopPropagation()}>
                   <button className="w-8 h-8 rounded-full bg-white/90 shadow-sm flex items-center justify-center border border-black/5 active:scale-90 transition-transform"><Heart size={16} /></button>
                   <button className="w-8 h-8 rounded-full bg-white/90 shadow-sm flex items-center justify-center border border-black/5 active:scale-90 transition-transform"><RotateCw size={16} /></button>
                </div>

                {/* Info Outfit */}
                <div className="space-y-1">
                   <span className="mono text-[10px] uppercase text-[#999] tracking-wider">{o.occasion}</span>
                   <h3 className="text-[17px] font-bold">{o.name}</h3>
                   <div className="flex flex-wrap gap-1.5 mt-2">
                      <span className="px-2 py-0.5 rounded-pill bg-[#F5F5F5] text-[10px] font-medium text-[#555]">✓ Para tu silueta</span>
                      <span className="px-2 py-0.5 rounded-pill bg-[#F5F5F5] text-[10px] font-medium text-[#555]">✓ Tu paleta</span>
                   </div>
                </div>

                {/* Parte Expandible */}
                <motion.div 
                  initial={false}
                  animate={{ height: isExpanded ? 'auto' : 0, opacity: isExpanded ? 1 : 0 }}
                  className="overflow-hidden"
                >
                  <div className="pt-4 space-y-2">
                    <div className="bg-[#F8F8F6] rounded-12px p-2.5">
                      <p className="mono text-[9px] text-[#999] mb-1">TU SILUETA RELOJ DE ARENA</p>
                      <p className="serif italic text-[13px] leading-tight text-estela-black">{o.bodyTip}</p>
                    </div>
                    <div className="bg-[#F8F8F6] rounded-12px p-2.5">
                      <p className="mono text-[9px] text-[#999] mb-1">TU PALETA OTOÑO</p>
                      <p className="serif italic text-[13px] leading-tight text-estela-black">{o.colorTip}</p>
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* 5. Dots Paginación */}
      <div className="flex justify-center gap-1.5 mt-4 mb-10">
        {filteredOutfits.map((_, i) => (
          <div key={i} className={`h-1 rounded-full transition-all ${i === 0 ? 'w-4 bg-estela-black' : 'w-1 bg-[#DCDCDC]'}`} />
        ))}
      </div>

      {/* 6. Tus Colores */}
      <section className="px-6 mb-12">
        <div className="flex justify-between items-end mb-4">
          <div>
            <h2 className="serif text-[20px] leading-tight">Tus colores</h2>
            <p className="text-[11px] text-[#999]">Paleta Otoño</p>
          </div>
        </div>
        <div className="scroll-hide flex gap-4 pb-2">
          {PALETAS.Otoño.slice(0, 6).map((c, i) => {
            const names = ["Terracota", "Mostaza", "Oliva", "Burdeos", "Crema", "Chocolate"];
            return (
              <div key={c} className="flex flex-col items-center gap-2 shrink-0">
                <div className="w-8 h-8 rounded-full shadow-sm border-2 border-white" style={{ background: c }} />
                <span className="mono text-[8px] text-[#999]">{names[i]}</span>
              </div>
            );
          })}
        </div>
      </section>

      <div className="h-[6px] bg-[#F3F3F3] mb-10" />

      {/* 8. Maquillaje */}
      <section className="mb-12">
        <header className="px-6 flex justify-between items-baseline mb-6">
          <h2 className="serif text-[20px]">Maquillaje</h2>
          <span className="text-[11px] text-[#999]">Rostro ovalado · Otoño</span>
        </header>

        <div className="scroll-hide flex gap-4 px-6 snap-container">
          {MAKEUP_LOOKS.map((look) => {
            const isExp = expandedMakeupId === look.name;
            return (
              <div 
                key={look.name} 
                onClick={() => setExpandedMakeupId(isExp ? null : look.name)}
                className="snap-item w-[260px] bg-white border border-[#EBEBEB] rounded-16px p-4 flex flex-col gap-4 cursor-pointer"
              >
                <div className="flex justify-between items-center">
                  <h3 className="text-[15px] font-bold">{look.name}</h3>
                  <span className="px-2 py-0.5 rounded-full bg-[#F3F3F3] text-[9px] font-bold text-[#555] uppercase">{look.vibe}</span>
                </div>

                <div className="space-y-3">
                  {look.steps.map((s, idx) => (
                    <div key={idx} className="flex items-center gap-3">
                      <div className="w-7 h-7 rounded-8px shadow-sm border border-black/5 shrink-0" style={{ backgroundColor: s.color }} />
                      <div className="min-w-0">
                        <p className="mono text-[9px] text-[#999] tracking-wider">{s.area}</p>
                        <p className="text-[12px] truncate">{s.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <motion.div animate={{ height: isExp ? 'auto' : 0, opacity: isExp ? 1 : 0 }} className="overflow-hidden">
                  <div className="pt-2 border-t border-[#F0F0F0] mt-2">
                    <p className="serif italic text-[12px] text-estela-gray leading-tight">{look.tip}</p>
                  </div>
                </motion.div>
              </div>
            );
          })}
        </div>
      </section>

      <div className="h-[6px] bg-[#F3F3F3] mb-10" />

      {/* 10. Peinados */}
      <section className="px-6 mb-12">
        <header className="flex justify-between items-baseline mb-6">
          <h2 className="serif text-[20px]">Peinados</h2>
          <span className="text-[11px] text-[#999]">Cara ovalada · Otoño</span>
        </header>

        <div className="flex flex-col gap-2">
          {HAIRSTYLES.map((hair) => {
            const isExp = expandedHairId === hair.id;
            return (
              <div 
                key={hair.id}
                onClick={() => setExpandedHairId(isExp ? null : hair.id)}
                className="bg-white border border-[#EBEBEB] rounded-14px p-3.5 transition-all cursor-pointer"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-14px bg-[#F3F3F3] flex items-center justify-center text-xl shrink-0">
                    {hair.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-[14px] font-bold leading-none mb-1">{hair.name}</h3>
                    <p className="text-[11px] text-[#999] uppercase tracking-wider">{hair.occasion}</p>
                  </div>
                  <motion.div animate={{ rotate: isExp ? 90 : 0 }}>
                    <ChevronRight size={18} className="text-[#CCC]" />
                  </motion.div>
                </div>

                <motion.div animate={{ height: isExp ? 'auto' : 0, opacity: isExp ? 1 : 0 }} className="overflow-hidden">
                  <div className="pt-4 border-t border-[#F0F0F0] mt-4">
                    <p className="text-[13px] text-[#555] mb-2">{hair.desc}</p>
                    <p className="serif italic text-[12px] text-[#999] ml-1">
                      <span className="mr-1">↳</span>
                      {hair.tip}
                    </p>
                  </div>
                </motion.div>
              </div>
            );
          })}
        </div>
      </section>

      <div className="h-[6px] bg-[#F3F3F3] mb-10" />

      {/* 12. Prendas Olvidadas */}
      <section className="px-6 pb-12">
        <h2 className="text-[17px] font-bold mb-4">Prendas olvidadas</h2>
        <div className="scroll-hide flex gap-4">
          {GARMENTS.slice(0, 8).map((p, i) => (
            <div key={p.id} className="flex flex-col items-center gap-2">
               <div className="w-16 h-16 rounded-full border-2 border-[#EBEBEB] flex items-center justify-center p-3 bg-white">
                  <div className="w-full h-full rounded-8px shadow-inner" style={{ background: p.mainColor }} />
               </div>
               <span className="mono text-[9px] text-[#999]">{[32, 28, 45, 12, 18, 50, 4, 15][i]} días</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );

  const renderClosetScreen = () => {
    const categories = [
      { name: "Todo", count: GARMENTS.length },
      { name: "Tops", count: GARMENTS.filter(g => g.category === "Tops").length },
      { name: "Bottoms", count: GARMENTS.filter(g => g.category === "Bottoms").length },
      { name: "Calzado", count: GARMENTS.filter(g => g.category === "Calzado").length },
      { name: "Outer", count: GARMENTS.filter(g => g.category === "Outer").length },
      { name: "Accesorios", count: GARMENTS.filter(g => g.category === "Accesorios").length },
    ];

    let filteredGarments = activeClosetCategory === "Todo" 
      ? GARMENTS 
      : GARMENTS.filter(g => g.category === activeClosetCategory);

    if (closetSort === "Recientes") {
      filteredGarments = [...filteredGarments].sort((a, b) => a.daysAgo - b.daysAgo);
    } else if (closetSort === "Más usadas") {
      filteredGarments = [...filteredGarments].sort((a, b) => b.uses - a.uses);
    } else if (closetSort === "Menos usadas") {
      filteredGarments = [...filteredGarments].sort((a, b) => a.uses - b.uses);
    }

    return (
      <div className="flex-1 flex flex-col bg-white">
        <header className="px-6 pt-[52px] pb-6 flex flex-col">
          <div className="flex items-center gap-3 mb-2">
            <h1 className="serif text-[24px]">Mi Armario</h1>
            <span className="bg-[#0A0A0A] text-white text-[12px] font-semibold px-[10px] py-[2px] rounded-[12px]">{GARMENTS.length}</span>
          </div>
          <p className="mono text-[11px] text-[#AAA]">Valor estimado: $2,400 · Costo/uso: $3.20</p>
        </header>

        <div className="scroll-hide flex gap-[20px] px-5 mb-4 border-b border-black/5">
          {categories.map((cat) => {
            const isActive = activeClosetCategory === cat.name;
            return (
              <button 
                key={cat.name} 
                onClick={() => setActiveClosetCategory(cat.name)}
                className={`pb-2 transition-all flex items-baseline gap-1.5 whitespace-nowrap border-b-[2.5px] ${isActive ? 'text-[#0A0A0A] font-semibold border-[#0A0A0A]' : 'text-[#AAA] font-normal border-transparent'}`}
              >
                <span className="text-[14px]">{cat.name}</span>
                <span className="text-[10px] opacity-60">({cat.count})</span>
              </button>
            );
          })}
        </div>

        <div className="px-5 mb-4 flex gap-1.5 text-[12px]">
          {["Recientes", "Más usadas", "Menos usadas"].map((sort, i) => (
            <React.Fragment key={sort}>
              <button 
                onClick={() => setClosetSort(sort)}
                className={`transition-colors h-6 flex items-center ${closetSort === sort ? 'text-black font-semibold' : 'text-[#BBB] font-normal'}`}
              >
                {sort}
              </button>
              {i < 2 && <span className="text-[#BBB] self-center"> · </span>}
            </React.Fragment>
          ))}
        </div>

        <div className="grid grid-cols-3 gap-2 px-4 pb-12">
          <AnimatePresence mode="popLayout">
            {filteredGarments.map((g, idx) => (
              <motion.div 
                key={g.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ delay: idx * 0.04, duration: 0.15 }}
                onClick={() => { setSelectedGarment(g); setIsGarmentModalOpen(true); }}
                className="aspect-[3/4] rounded-[14px] bg-[#F5F5F5] overflow-hidden cursor-pointer active:scale-[0.97] transition-transform flex flex-col"
              >
                <div className="flex-1 flex items-center justify-center relative p-3 overflow-hidden" style={{ background: `${g.mainColor}15` }}>
                   {/* Visual Representation */}
                   <div className={`shadow-sm transition-transform ${g.category === 'Tops' ? 'w-full h-[80%] rounded-t-[12px] rounded-b-[4px]' : g.category === 'Bottoms' ? 'w-[60%] h-full rounded-[4px]' : g.category === 'Calzado' ? 'w-[80%] h-[40%] rounded-[6px]' : 'w-[40%] h-[40%] rounded-full'}`} style={{ backgroundColor: g.mainColor }} />
                </div>
                <div className="h-[40px] p-2 bg-white flex flex-col justify-between">
                  <p className="text-[11px] font-semibold leading-none truncate">{g.name}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex gap-[3px]">
                      {g.dots.map((c, i) => <div key={i} className="w-[6px] h-[6px] rounded-full border border-black/5" style={{ backgroundColor: c }} />)}
                    </div>
                    <span className="mono text-[9px] text-[#BBB]">×{g.uses}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Floating Action Button for Closetscreen specifically mentioned as plus button in circle in navigation section */}
      </div>
    );
  };  const renderAddGarmentScreen = () => {
    const handleSaveGarment = () => {
      // Simulate saving to closet
      setActiveScreen("closet");
      setAddGarmentStep(1);
      setShowAnalysisResult(false);
    };

    return (
      <div className="flex-1 flex flex-col min-h-0 bg-[#FAFAFA] relative overflow-hidden">
        <AnimatePresence mode="wait">
          {addGarmentStep === 1 ? (
            <motion.div 
              key="camera-step" 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ y: "-100%", opacity: 0 }}
              transition={{ duration: 0.3, ease: "easeInOut" }}
              className="flex-1 flex flex-col"
            >
              <header className="px-6 pt-12 pb-4 flex items-center justify-between bg-white relative z-20">
                <button 
                  onClick={() => setActiveScreen("home")} 
                  className="text-[14px] font-medium flex items-center gap-1 active:opacity-50"
                >
                  <ChevronLeft size={18} /> Atrás
                </button>
                <h2 className="text-[16px] font-semibold flex-1 text-center pr-10">Nueva prenda</h2>
              </header>

              <div className="flex-1 flex flex-col relative z-10 px-4 pt-3 pb-6">
                 {/* Viewfinder Area (75% height approx via flex) */}
                 <div className="flex-[0.75] bg-[#1A1A1A] rounded-[20px] relative overflow-hidden flex flex-col items-center justify-center">
                    {/* Shutter Flash Effect */}
                    <AnimatePresence>
                      {shutterEffect && (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-white z-[100]" />
                      )}
                    </AnimatePresence>

                    {/* Corner Brackets */}
                    <div className="absolute top-4 left-4 w-7 h-7 border-t-2 border-l-2 border-white/80" />
                    <div className="absolute top-4 right-4 w-7 h-7 border-t-2 border-r-2 border-white/80" />
                    <div className="absolute bottom-4 left-4 w-7 h-7 border-b-2 border-l-2 border-white/80" />
                    <div className="absolute bottom-4 right-4 w-7 h-7 border-b-2 border-r-2 border-white/80" />

                    {/* Gallery Chip */}
                    <button 
                      onClick={() => {
                        setIsAnalyzing(true);
                        setAddGarmentStep(2);
                        setTimeout(() => {
                           setIsAnalyzing(false);
                           setShowAnalysisResult(true);
                        }, 2000);
                      }}
                      className="absolute top-4 left-1/2 -translate-x-1/2 bg-white/15 backdrop-blur-md px-4 py-2 rounded-full flex items-center gap-2 border border-white/10 active:scale-95 transition-transform"
                    >
                       <Camera size={14} className="text-white" />
                       <span className="text-[12px] text-white font-medium">Galería</span>
                    </button>

                    {/* Center Decoration */}
                    <div className="flex flex-col items-center gap-3 opacity-30">
                       <Shirt size={48} className="text-white" />
                       <span className="text-[14px] text-white">Enfoca tu prenda</span>
                    </div>

                    {/* Scanner Simulation Line */}
                    <motion.div 
                      animate={{ top: ['20%', '80%', '20%'] }}
                      transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                      className="absolute left-6 right-6 h-[1px] bg-white/20 shadow-[0_0_8px_rgba(255,255,255,0.4)]"
                    />
                 </div>

                 {/* Bottom Zone */}
                 <div className="flex-1 flex flex-col items-center justify-center pt-8">
                    <div className="relative group">
                       <button 
                         onClick={() => {
                           setShutterEffect(true);
                           setTimeout(() => setShutterEffect(false), 150);
                           setTimeout(() => {
                             setIsAnalyzing(true);
                             setAddGarmentStep(2);
                             setTimeout(() => {
                               setIsAnalyzing(false);
                               setShowAnalysisResult(true);
                             }, 2000);
                           }, 300);
                         }}
                         className="w-[68px] h-[68px] rounded-full border-[3px] border-black flex items-center justify-center active:scale-90 transition-all duration-150 relative mb-3 hover:bg-black/5"
                       >
                         <div className="w-[56px] h-[56px] bg-black rounded-full" />
                       </button>
                    </div>
                    <p className="text-[12px] text-[#BBB] font-medium tracking-wide">Toca para capturar</p>
                 </div>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="analysis-step" 
              initial={{ y: "100%" }} 
              animate={{ y: 0 }} 
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="flex-1 flex flex-col bg-white"
            >
              <header className="px-6 pt-12 flex justify-between items-center border-b border-black/5 pb-4 shrink-0 bg-white">
                 <button onClick={() => { setAddGarmentStep(1); setShowAnalysisResult(false); }} className="text-[14px] text-estela-black flex items-center gap-1 font-medium">
                    <ChevronLeft size={16} /> Reintentar
                 </button>
                 <span className="text-[16px] font-semibold">Nueva prenda</span>
                 <div className="w-10" />
              </header>

              <div className="flex-1 overflow-y-auto no-scrollbar p-6">
                <div className={`rounded-[24px] bg-[#F8F8F8] h-[280px] mb-8 flex items-center justify-center relative overflow-hidden shadow-inner group ${isAnalyzing ? 'animate-pulse' : ''}`}>
                  {isAnalyzing ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/60 backdrop-blur-sm z-20">
                       <div className="relative w-16 h-16 mb-4">
                          <div className="absolute inset-0 border-4 border-black/5 rounded-full" />
                          <div className="absolute inset-0 border-4 border-black border-t-transparent rounded-full animate-spin" />
                       </div>
                       <p className="text-[14px] font-bold tracking-tight text-black uppercase animate-pulse">Analizando...</p>
                    </div>
                  ) : (
                    <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex flex-col items-center">
                       <div className="relative">
                          <div className="w-32 h-44 bg-[#2C5F8A] rounded-[8px] shadow-2xl transform rotate-2 relative z-10" />
                          <div className="absolute -top-2 -right-2 bg-black text-white px-2 py-1 rounded text-[10px] font-bold z-20">98% MATCH</div>
                       </div>
                    </motion.div>
                  )}
                  {/* Analysis shimmer overlay */}
                  {isAnalyzing && (
                    <motion.div 
                      key="scanner"
                      initial={{ top: '-10%' }}
                      animate={{ top: '110%' }}
                      transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                      className="absolute left-0 right-0 h-10 bg-gradient-to-b from-transparent via-black/10 to-transparent z-10"
                    />
                  )}
                </div>

                {showAnalysisResult && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="mono text-[10px] text-[#BBB] uppercase font-bold tracking-widest">DETECCIÓN IA</h3>
                      
                      {[
                        { l: "CATEGORÍA", v: "Top — Camisa", c: "94%" },
                        { l: "MATERIAL", v: "Algodón Oxford", c: "91%" },
                        { l: "PATRÓN", v: "Liso", c: "87%" },
                        { l: "ESTILO", v: "Smart Casual", c: "89%" }
                      ].map((row, i) => (
                        <motion.div 
                          key={row.l} 
                          initial={{ opacity: 0, x: -10 }} 
                          animate={{ opacity: 1, x: 0 }} 
                          transition={{ delay: i * 0.1 }}
                          className="flex justify-between items-baseline p-3 bg-[#FAFAFA] rounded-[12px] border border-[#F0F0F0]"
                        >
                          <span className="mono text-[10px] text-[#999]">{row.l}</span>
                          <div className="flex gap-2 items-baseline">
                            <span className="text-[13px] font-bold">{row.v}</span>
                            <span className="mono text-[9px] text-[#CCC]">{row.c}</span>
                          </div>
                        </motion.div>
                      ))}

                      <motion.div 
                        initial={{ opacity: 0, y: 10 }} 
                        animate={{ opacity: 1, y: 0 }} 
                        transition={{ delay: 0.4 }} 
                        className="flex justify-between items-center p-3 bg-[#FAFAFA] rounded-[12px] border border-[#F0F0F0]"
                      >
                        <span className="mono text-[10px] text-[#999]">COLORES DETECTADOS</span>
                        <div className="flex gap-1.5">
                           {["#2C5F8A", "#FFFFFF", "#D4D4D4"].map(c => <div key={c} className="w-5 h-5 rounded-full border border-black/5" style={{ background: c }} />)}
                        </div>
                      </motion.div>
                    </div>

                    <div className="pt-8 pb-12">
                      <button 
                        onClick={handleSaveGarment} 
                        className="bg-estela-black text-white w-full h-[56px] rounded-[16px] font-bold text-[15px] shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2"
                      >
                        Guardar en mi armario <Check size={18} />
                      </button>
                      <button onClick={() => setAddGarmentStep(1)} className="w-full text-center mt-4 text-[#BBB] text-[13px] font-medium">Descartar y repetir</button>
                    </div>
                  </motion.div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };

  const MiniAvatar = ({ top, bottom, shoes, outer, size = 36 }: { top: string, bottom: string, shoes: string, outer?: string, size?: number }) => (
    <svg width={size} height={size} viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="18" cy="6" r="3" fill="black" />
      <rect x="10" y="10" width="16" height="12" rx="2" fill={top} />
      <rect x="12" y="22" width="12" height="10" rx="1" fill={bottom} />
      <rect x="11" y="32" width="14" height="3" rx="1" fill={shoes} />
      {outer && <rect x="9" y="10" width="18" height="11" rx="2" fill={outer} fillOpacity="0.4" />}
    </svg>
  );

  const LargeAvatar = ({ top, bottom, shoes, outer }: { top: string, bottom: string, shoes: string, outer?: string }) => (
    <div className="relative flex items-center justify-center py-6">
      <div className="absolute w-[180px] h-[180px] rounded-full blur-3xl opacity-20" style={{ background: `radial-gradient(circle, ${top} 0%, transparent 70%)` }} />
      <svg width="100" height="150" viewBox="0 0 80 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="relative z-10 drop-shadow-xl">
        <circle cx="40" cy="15" r="6" fill="black" />
        <rect x="38" y="21" width="4" height="4" fill="black" />
        <rect x="15" y="25" width="8" height="25" rx="3" fill={top} />
        <rect x="57" y="25" width="8" height="25" rx="3" fill={top} />
        <rect x="20" y="25" width="40" height="30" rx="4" fill={top} />
        {outer && <rect x="18" y="25" width="44" height="32" rx="4" fill={outer} fillOpacity="0.6" />}
        <rect x="25" y="55" width="14" height="35" rx="2" fill={bottom} />
        <rect x="41" y="55" width="14" height="35" rx="2" fill={bottom} />
        <ellipse cx="32" cy="93" rx="8" ry="3" fill={shoes} />
        <ellipse cx="48" cy="93" rx="8" ry="3" fill={shoes} />
      </svg>
    </div>
  );

  const APRIL_LOG = {
    3: { slots: { morning: 'ca-1', afternoon: 'ca-1' } },
    4: { slots: { morning: 'of-2' } },
    6: { slots: { morning: 'ca-3' } },
    8: { slots: { morning: 'of-1' } },
    9: { slots: {} }, // Sin outfits
    10: { slots: { morning: 'of-3' } },
    11: { slots: { morning: 'of-2', night: 'ci-1' } },
    12: { slots: { morning: 'ca-2' } },
    15: { slots: { morning: 'ca-4' } },
    16: { slots: { morning: 'of-4' } },
    17: { slots: { morning: 'of-1' } },
    18: { slots: { morning: 'ca-1', night: 'ci-2' } },
    19: { slots: { morning: 'ca-3' } },
    20: { slots: { morning: 'ev-1' } },
    22: { slots: { morning: 'of-4', night: 'ci-1' } },
    23: { slots: { morning: 'of-3' } },
    24: { slots: { morning: 'ca-4' } },
    25: { slots: { morning: 'ca-1' } },
    26: { slots: { morning: 'of-2' } },
    27: { slots: { morning: 'ca-2' } },
    28: { slots: { morning: 'ca-3' } },
  };

  const getOutfitById = (id: string) => {
    const outfit = OUTFITS_DATA.find(o => o.id === id);
    if (!outfit) return null;
    
    // Enrich garments for specific outfits requested
    let garments = [
      { name: "Top", color: outfit.colors[0] },
      { name: "Bottom", color: outfit.colors[1] },
      { name: "Calzado", color: outfit.colors[2] }
    ];
    
    if (outfit.id === 'of-4') {
      garments = [
        { name: "Camisa Oxford Blanca", color: "#F8F8F8" },
        { name: "Chino Beige", color: "#D4C5A9" },
        { name: "Botines Chelsea", color: "#1A1A1A" }
      ];
    } else if (outfit.id === 'ci-1') {
      garments = [
        { name: "Suéter Crema Cuello Alto", color: "#F5E6D3" },
        { name: "Falda Midi Plisada", color: "#1A1A1A" },
        { name: "Botines Chelsea", color: "#1A1A1A" },
        { name: "Bufanda Gris", color: "#9E9E9E" }
      ];
    } else if (outfit.id === 'ca-1') {
      garments = [
        { name: "Camiseta Negra", color: "#1A1A1A" },
        { name: "Jeans Slim Oscuros", color: "#2C3E6B" },
        { name: "Sneakers Blancos", color: "#F5F5F5" },
        { name: "Bolso Tote Negro", color: "#2A2A2A" }
      ];
    }

    return { ...outfit, garments };
  };

  const DetailedAvatar = ({ outfit, size = { w: 60, h: 85 } }: { outfit: any, size?: { w: number, h: number } }) => {
    if (!outfit) return null;
    const g = outfit.garments || [];
    const top = g.find((x: any) => x.name.toLowerCase().includes('top') || x.name.toLowerCase().includes('camisa') || x.name.toLowerCase().includes('suéter') || x.name.toLowerCase().includes('camiseta'))?.color || outfit.colors[0];
    const bottom = g.find((x: any) => x.name.toLowerCase().includes('bottom') || x.name.toLowerCase().includes('chino') || x.name.toLowerCase().includes('jeans') || x.name.toLowerCase().includes('falda') || x.name.toLowerCase().includes('pantalón'))?.color || outfit.colors[1];
    const shoes = g.find((x: any) => x.name.toLowerCase().includes('calzado') || x.name.toLowerCase().includes('botín') || x.name.toLowerCase().includes('zapa') || x.name.toLowerCase().includes('sneaker'))?.color || outfit.colors[2];
    const outer = g.find((x: any) => x.name.toLowerCase().includes('outer') || x.name.toLowerCase().includes('blazer'))?.color || (outfit.colors.length > 3 ? outfit.colors[3] : null);
    const accessory = g.find((x: any) => x.name.toLowerCase().includes('bolso'))?.color;
    const scarf = g.find((x: any) => x.name.toLowerCase().includes('bufanda'))?.color;

    return (
      <svg width={size.w} height={size.h} viewBox="0 0 60 85" fill="none" xmlns="http://www.w3.org/2000/svg" className="drop-shadow-sm">
        {/* Cabeza */}
        <circle cx="30" cy="8" r="6" fill="#0A0A0A" />
        {/* Cuello */}
        <rect x="27" y="14" width="6" height="4" fill={top} />
        {/* Torso / Top */}
        <rect x="12" y="18" width="36" height="24" rx="4" fill={top} />
        <rect x="6" y="18" width="10" height="6" rx="2" fill={top} />
        <rect x="44" y="18" width="10" height="6" rx="2" fill={top} />
        
        {/* Outerwear */}
        {outer && <rect x="8" y="16" width="44" height="28" rx="4" fill={outer} fillOpacity="0.6" stroke={outer} strokeOpacity="0.3" />}
        
        {/* Piernas / Bottom */}
        <rect x="16" y="44" width="11" height="28" rx="3" fill={bottom} />
        <rect x="33" y="44" width="11" height="28" rx="3" fill={bottom} />
        
        {/* Calzado */}
        <rect x="14" y="72" width="15" height="6" rx="3" fill={shoes} />
        <rect x="31" y="72" width="15" height="6" rx="3" fill={shoes} />
        
        {/* Accesorio (bolso) */}
        {accessory && <rect x="50" y="30" width="8" height="12" rx="2" fill={accessory} />}
        
        {/* Bufanda */}
        {scarf && <rect x="20" y="14" width="20" height="6" rx="2" fill={scarf} />}
      </svg>
    );
  };

  const renderCalendarScreen = () => {
    const daysInApril = 30;
    const April1stDay = 3; // Wednesday (0=Sun, 1=Mon, 2=Tue, 3=Wed...)
    
    const days = Array.from({ length: daysInApril }, (_, i) => i + 1);
    const blanks = Array.from({ length: April1stDay - 1 }, (_, i) => null); // Start from Monday
    const calendarGrid = [...blanks, ...days];

    const weekCurrent = [22, 23, 24, 25, 26, 27, 28];

    const renderMonthlyView = () => (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex-1 flex flex-col pt-12 bg-white overflow-hidden">
        <header className="px-6 mb-4 flex items-center justify-between font-medium shrink-0">
           <div className="flex items-center gap-4">
              <button className="p-1 active:scale-95 transition-transform"><ChevronLeft size={20}/></button>
              <h2 className="serif text-[22px]">Abril 2026</h2>
              <button className="p-1 active:scale-95 transition-transform"><ChevronRight size={20}/></button>
           </div>
           <div className="bg-[#F5F5F5] p-1 rounded-full flex gap-1">
              <button className="px-4 py-1.5 rounded-full bg-white text-[12px] font-bold shadow-sm">Mes</button>
              <button 
                onClick={() => setActiveCalendarView('daily')}
                className="px-4 py-1.5 rounded-full text-[12px] text-[#999] hover:text-black transition-colors"
              >
                Hoy
              </button>
           </div>
        </header>

        <div className="flex-1 overflow-y-auto no-scrollbar pb-24">
          <div className="px-6 mb-6">
             <p className="mono text-[11px] text-[#999]">18 outfits este mes · Racha: 5 días seguidos 🔥</p>
          </div>

        {/* Semana Rápida - Horizontal Scrollable */}
        <div className="mb-8">
           <div className="px-6 flex items-baseline justify-between mb-3">
              <h3 className="mono text-[10px] text-[#BBB] uppercase font-bold tracking-widest">Semana actual</h3>
              <span className="text-[11px] text-[#DDD]">Abr 20 – 26</span>
           </div>
           <div className="flex gap-3 overflow-x-auto px-6 pb-2 no-scrollbar scroll-smooth touch-pan-x">
              {[20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30].map((dayNum) => {
                const data = (agendaLog as any)[dayNum];
                const isCurrent = dayNum === 28;
                const date = new Date(2026, 3, dayNum);
                const dayLabel = ['D', 'L', 'M', 'M', 'J', 'V', 'S'][date.getDay()];
                
                return (
                  <div key={dayNum} className="flex flex-col items-center gap-2 shrink-0">
                    <span className="mono text-[10px] text-[#AAA]">{dayLabel}</span>
                    <button 
                      onClick={() => { setSelectedCalendarDate(dayNum); setActiveCalendarView('daily'); }}
                      className={`w-[52px] h-[52px] rounded-[16px] flex items-center justify-center transition-all ${isCurrent ? 'bg-black text-white shadow-lg scale-105' : 'bg-[#F8F8F8] border border-[#F0F0F0] active:scale-95'}`}
                    >
                      {data?.slots?.morning && !isCurrent ? (
                        <MiniAvatar 
                          top={getOutfitById(data.slots.morning)?.colors[0] || "#EEE"} 
                          bottom={getOutfitById(data.slots.morning)?.colors[1] || "#EEE"} 
                          shoes={getOutfitById(data.slots.morning)?.colors[2] || "#EEE"} 
                          size={32}
                        />
                      ) : <span className={`text-[15px] font-bold ${isCurrent ? 'text-white' : 'text-black'}`}>{dayNum}</span>}
                    </button>
                  </div>
                );
              })}
           </div>
        </div>

        {/* Grid Calendario */}
        <div className="px-4 mb-4">
           <div className="grid grid-cols-7 text-center mb-2 px-2">
              {['L', 'M', 'M', 'J', 'V', 'S', 'D'].map((d, i) => <span key={`${d}-${i}`} className="mono text-[10px] text-[#AAA] py-2 uppercase tracking-widest">{d}</span>)}
           </div>
           <div className="grid grid-cols-7 gap-1">
              {calendarGrid.map((d, i) => {
                const dayLog = d ? (agendaLog as any)[d] : null;
                const isToday = d === 28;
                const isFuture = d && d > 28;
                const outfitsCount = dayLog ? Object.keys(dayLog.slots).length : 0;

                return (
                  <div 
                    key={i} 
                    onClick={() => { if(d && !isFuture) { setSelectedCalendarDate(d); setActiveCalendarView('daily'); } }}
                    style={{ transitionDelay: `${Math.floor(i / 7) * 0.05}s` }}
                    className={`h-[56px] rounded-[12px] relative flex items-center justify-center transition-all duration-300 animate-in fade-in slide-in-from-bottom-2 ${!d ? 'invisible' : ''} ${dayLog ? 'bg-[#F3F3F3] active:scale-95' : 'bg-transparent'} ${isFuture ? 'opacity-30 cursor-default' : 'cursor-pointer hover:bg-black/5'}`}
                  >
                    {d && (
                      <>
                        <span className={`absolute top-1 right-1 mono text-[9px] w-[22px] h-[22px] flex items-center justify-center rounded-full z-10 ${isToday ? 'bg-[#0A0A0A] text-white shadow-md' : 'text-[#CCC]'}`}>{d}</span>
                        {dayLog && dayLog.slots?.morning ? (
                          <div className="flex flex-col items-center gap-1 mt-1">
                             <MiniAvatar 
                               top={getOutfitById(dayLog.slots.morning)?.colors[0] || "#EEE"} 
                               bottom={getOutfitById(dayLog.slots.morning)?.colors[1] || "#EEE"} 
                               shoes={getOutfitById(dayLog.slots.morning)?.colors[2] || "#EEE"} 
                               size={36}
                             />
                             {outfitsCount > 1 && (
                               <div className="flex gap-0.5 absolute bottom-1.5">
                                  {Array.from({ length: outfitsCount }).map((_, i) => <div key={i} className="w-[4px] h-[4px] rounded-full bg-black" />)}
                               </div>
                             )}
                          </div>
                        ) : d && !isToday &&(
                          <span className="text-[12px] text-[#CCC] font-medium">{d}</span>
                        )}
                      </>
                    )}
                  </div>
                );
              })}
           </div>
        </div>

        <div className="h-[1px] bg-[#EEE] mx-6 mb-8" />

        {/* Stats */}
        <section className="px-6 mb-10">
           <h2 className="serif text-[18px] mb-4">Tu mes en números</h2>
           <div className="grid grid-cols-2 gap-2">
              <div className="bg-[#F5F5F5] rounded-[14px] p-3.5 flex flex-col justify-between h-[126px]">
                 <div className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center self-start overflow-hidden border border-black/5">
                    <div className="w-full h-full" style={{ background: '#1A1A1A' }} />
                 </div>
                 <div>
                    <h4 className="text-[13px] font-bold">Camiseta Negra</h4>
                    <p className="mono text-[10px] text-[#999]">Usada 12 veces</p>
                 </div>
              </div>
              <div className="bg-[#F5F5F5] rounded-[14px] p-3.5 flex flex-col justify-between h-[126px]">
                 <span className="serif text-[32px] leading-none">18</span>
                 <p className="text-[11px] text-[#999] leading-tight">combinaciones diferentes</p>
              </div>
              <div className="bg-[#F5F5F5] rounded-[14px] p-3.5 flex flex-col justify-between h-[126px]">
                 <span className="serif text-[32px] leading-none text-[#999]">3</span>
                 <div>
                    <p className="text-[11px] text-[#999] leading-tight">prendas olvidadas</p>
                    <p className="text-[9px] text-[#BBB] mt-1 truncate">Vestido Oliva, Bufanda, Falda Midi</p>
                 </div>
              </div>
              <div className="bg-[#F5F5F5] rounded-[14px] p-3.5 flex flex-col justify-between h-[126px]">
                 <span className="serif text-[32px] leading-none">5 🔥</span>
                 <p className="text-[11px] text-[#999] leading-tight">días seguidos registrando</p>
              </div>
           </div>
        </section>

        {/* Viaje de Estilo */}
        <section className="px-6 pb-24">
           <h2 className="serif text-[18px] mb-4">Tu evolución este mes</h2>
           <div className="scroll-hide flex gap-3 overflow-x-auto pb-4">
              {[
                "Semana 1: Dominó el negro — 70% de tus outfits fueron base oscura",
                "Semana 2: Exploraste color — usaste oliva y crema por primera vez",
                "Semana 3: Modo capas — 4 outfits con 3+ prendas",
                "Semana 4: Tu mejor semana — 5 outfits únicos seguidos"
              ].map((text, i) => (
                <div key={i} className="min-w-[200px] bg-[#F5F5F5] border border-[#EBEBEB] rounded-[14px] p-4 flex flex-col gap-2 shadow-sm">
                   <span className="mono text-[10px] text-[#BBB] uppercase font-bold tracking-widest">Semana 0{i+1}</span>
                   <p className="text-[12px] leading-tight text-[#555] font-medium">{text}</p>
                </div>
              ))}
           </div>
        </section>
        </div>
      </motion.div>
    );

    const renderDailyView = () => {
      const log = (agendaLog as any)[selectedCalendarDate];
      const moments = [
        { id: 'morning', label: 'Mañana', icon: '☀️', time: '7:00 – 12:00' },
        { id: 'afternoon', label: 'Tarde', icon: '🌤', time: '12:00 – 19:00' },
        { id: 'night', label: 'Noche', icon: '🌙', time: '19:00 – 23:00' }
      ];

      const outfitsInDay = moments.map(m => {
        const id = log?.slots?.[m.id];
        return id ? getOutfitById(id) : null;
      }).filter(Boolean);

      const uniqueOutfits = Array.from(new Set(outfitsInDay.map(o => o.id))).map(id => outfitsInDay.find(o => o.id === id));

      const handleDayChange = (dir: 'prev' | 'next') => {
        const newDay = dir === 'prev' ? selectedCalendarDate - 1 : selectedCalendarDate + 1;
        if (newDay >= 1 && newDay <= 28) {
          setSelectedCalendarDate(newDay);
        }
      };

      const handleTouchStart = (e: React.TouchEvent) => {
        touchStartX.current = e.touches[0].clientX;
      };

      const handleTouchEnd = (e: React.TouchEvent) => {
        const touchEndX = e.changedTouches[0].clientX;
        const diff = touchStartX.current - touchEndX;
        if (Math.abs(diff) > 50) {
          handleDayChange(diff > 0 ? 'next' : 'prev');
        }
      };

      const getDayName = (day: number) => {
        const days = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
        // April 2026 starts on Wednesday (3)
        // Adjust for grid logic
        const date = new Date(2026, 3, day);
        return days[date.getDay()];
      };

      return (
        <motion.div 
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }}
          className="flex-1 flex flex-col bg-[#FAFAFA]"
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        >
          {/* Zona A: Header & Day Navigator */}
          <header className="bg-white border-b border-[#EBEBEB] z-30">
            <div className="px-6 pt-12 pb-2 flex items-center justify-between">
              <button 
                onClick={() => setActiveCalendarView('monthly')} 
                className="text-[14px] text-estela-black flex items-center gap-1 font-medium active:opacity-50"
              >
                <ChevronLeft size={16} /> Volver
              </button>
              <div className="flex gap-4">
                 <button onClick={() => handleDayChange('prev')} disabled={selectedCalendarDate <= 1} className="p-2 active:scale-90 disabled:opacity-20 text-black/40"><ChevronLeft size={20} /></button>
                 <button onClick={() => handleDayChange('next')} disabled={selectedCalendarDate >= 30} className="p-2 active:scale-90 disabled:opacity-20 text-black/40"><ChevronRight size={20} /></button>
              </div>
            </div>

            {/* Horizontal Scroll Day Picker */}
            <div 
              className="flex gap-1 overflow-x-auto px-4 pb-4 no-scrollbar scroll-smooth"
              onTouchStart={(e) => e.stopPropagation()}
              onTouchEnd={(e) => e.stopPropagation()}
            >
               {days.map((d) => {
                 const isSelected = selectedCalendarDate === d;
                 const dayNameShort = getDayName(d).substring(0, 1).toUpperCase();
                 const isTodayMark = d === 28;
                 
                 return (
                   <button 
                     key={d} 
                     id={`day-nav-${d}`}
                     onClick={() => setSelectedCalendarDate(d)}
                     className={`flex flex-col items-center min-w-[50px] shrink-0 py-3 rounded-[16px] transition-all gap-1 ${isSelected ? 'bg-black text-white shadow-md' : 'text-[#BBB] hover:text-black'}`}
                   >
                      <span className="mono text-[10px] font-bold">{dayNameShort}</span>
                      <span className="text-[15px] font-bold">{d}</span>
                      {isTodayMark && !isSelected && <div className="w-1 h-1 rounded-full bg-black mt-0.5" />}
                   </button>
                 );
               })}
            </div>
            
            <div className="px-6 py-4 flex flex-col gap-0.5 border-t border-[#F8F8F8]">
               <h2 className="serif text-[24px] leading-tight font-normal">{getDayName(selectedCalendarDate)}, {selectedCalendarDate} de abril</h2>
               <div className="flex items-center gap-2">
                 <span className="mono text-[11px] text-[#BBB]">☁ 17°C · Bogotá · 18 outfits registrados</span>
               </div>
            </div>
          </header>

          <AnimatePresence mode="wait">
            <motion.div 
              key={selectedCalendarDate}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="flex-1 overflow-y-auto no-scrollbar pb-40"
              style={{ WebkitOverflowScrolling: 'touch' }}
            >
              {/* Zona B: Outfit Preview Horizontal */}
              {outfitsInDay.length > 0 && (
                <section className="bg-[#FAFAFA] border-b border-[#EBEBEB] py-6 overflow-hidden">
                  <div className="flex items-center justify-center gap-4">
                    {uniqueOutfits.map((o, idx) => (
                      <React.Fragment key={o.id}>
                        <div className="flex flex-col items-center gap-3">
                          <div className="w-[80px] h-[80px] rounded-full bg-gradient-radial from-[#F5F5F5] to-[#EAEAEA] flex items-center justify-center p-2 shadow-inner">
                             <DetailedAvatar outfit={o} size={{ w: 56, h: 80 }} />
                          </div>
                          <div className="text-center w-[100px]">
                            <p className="mono text-[9px] uppercase text-[#999] tracking-tighter mb-0.5">{idx === 0 ? 'Mañana' : 'Noche'}</p>
                            <p className="text-[11px] font-bold truncate leading-tight">{o.name}</p>
                          </div>
                        </div>
                        {idx < uniqueOutfits.length - 1 && <ChevronRight className="text-[#DDD] -mt-10" size={16} />}
                      </React.Fragment>
                    ))}
                  </div>
                </section>
              )}

              <div className="flex-none">
                <div className="p-6 relative">
                   {/* Timeline line */}
                   <div className="absolute left-[24px] top-8 bottom-8 w-[2px] bg-[#EBEBEB]" />

                   <div className="space-y-8">
                    {moments.map((m, mIdx) => {
                      const outfitId = log?.slots?.[m.id];
                      const outfit = outfitId ? getOutfitById(outfitId) : null;
                      const isMorning = m.id === 'morning';
                      const isSameAsMorning = m.id === 'afternoon' && log?.slots?.morning && outfitId === log.slots.morning;
                      const hasOutfit = !!outfit;
                      
                      const isExpanded = expandedOutfitId === `${selectedCalendarDate}-${m.id}`;

                      return (
                        <motion.div 
                          key={m.id}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.15 + mIdx * 0.1 }}
                          className="relative pl-11"
                        >
                          {/* Timeline Node */}
                          <div 
                            className={`absolute left-[-23px] top-1 w-[10px] h-[10px] rounded-full z-10 ${hasOutfit ? 'bg-[#0A0A0A]' : 'bg-[#E0E0E0]'} ${isSameAsMorning ? 'scale-75 ring-[3px] ring-white ring-offset-0' : ''}`}
                          />

                          <div className="flex items-center gap-2 mb-3">
                             <span className="text-[14px]">{m.icon}</span>
                             <span className="text-[13px] font-bold text-estela-black">{m.label}</span>
                             <span className="mono text-[11px] text-[#BBB] ml-1">{m.time}</span>
                          </div>

                          {isSameAsMorning ? (
                            <div className="h-[44px] bg-[#F8F8F8] border border-dashed border-[#DDD] rounded-[12px] flex items-center justify-center">
                               <p className="text-[12px] text-[#999]">↑ Mismo outfit de la mañana</p>
                            </div>
                          ) : hasOutfit ? (
                            <motion.div 
                              layout
                              onClick={() => setExpandedOutfitId(isExpanded ? null : `${selectedCalendarDate}-${m.id}`)}
                              className="bg-white rounded-[16px] border border-[#EBEBEB] p-4 shadow-sm active:scale-[0.98] transition-transform cursor-pointer"
                            >
                              <div className="flex gap-4">
                                 <div className="w-[80px] h-[100px] bg-[#F5F5F5] rounded-full flex items-center justify-center p-2 shrink-0">
                                    <DetailedAvatar outfit={outfit} size={{ w: 45, h: 65 }} />
                                 </div>
                                 <div className="flex-1 flex flex-col justify-center gap-2">
                                    <div className="flex items-start justify-between">
                                       <h3 className="text-[15px] font-bold leading-tight">{outfit.name}</h3>
                                       <span className="mono text-[9px] px-2 py-0.5 border border-[#EEE] rounded-full text-[#999] uppercase">{outfit.occasion}</span>
                                    </div>
                                    <div className="space-y-1">
                                       {outfit.garments.slice(0, 3).map((g: any, i: number) => (
                                         <div key={i} className="flex items-center gap-2">
                                            <div className="w-2 h-2 rounded-full shadow-inner" style={{ background: g.color }} />
                                            <span className="text-[11px] text-estela-gray truncate font-medium">{g.name}</span>
                                         </div>
                                       ))}
                                       {outfit.garments.length > 3 && <p className="text-[11px] text-[#BBB] ml-4">+ {outfit.garments.length - 3} más</p>}
                                    </div>
                                    <div className="flex gap-2 mt-1">
                                       {['😍', '😊', '😐', '😕', '😣'].map((emoji, i) => {
                                         const isSelected = (outfit.id === 'ci-1' && i === 0) || (outfit.id === 'of-4' && i === 1) || (outfit.id === 'ca-1' && i === 1) || (outfit.id === 'ci-2' && i === 0);
                                         return <span key={i} className={`text-[16px] transition-all ${isSelected ? 'opacity-100 scale-110' : 'opacity-20'}`}>{emoji}</span>;
                                       })}
                                    </div>
                                 </div>
                              </div>

                              <AnimatePresence>
                                {isExpanded && (
                                  <motion.div 
                                    initial={{ height: 0, opacity: 0 }}
                                    animate={{ height: 'auto', opacity: 1 }}
                                    exit={{ height: 0, opacity: 0 }}
                                    className="overflow-hidden no-scrollbar"
                                  >
                                    <div className="pt-4 mt-4 border-t border-[#F5F5F5] space-y-4">
                                       <div className="flex gap-3 overflow-x-auto pb-2 no-scrollbar">
                                          {outfit.garments.map((g: any, i: number) => (
                                            <div key={i} className="flex flex-col items-center gap-1.5 shrink-0">
                                               <div className="w-12 h-16 rounded-[8px] border border-black/5 flex items-center justify-center p-1.5" style={{ background: g.color }}>
                                                  <div className="w-full h-full bg-white/20 rounded-[4px]" />
                                               </div>
                                               <span className="text-[8px] text-[#999] max-w-[48px] text-center truncate">{g.name}</span>
                                            </div>
                                          ))}
                                       </div>
                                       <p className="serif italic text-[12px] text-[#999] leading-tight">
                                          "{outfit.bodyTip || 'Perfecto para tu silueta reloj de arena'}"<br/>
                                          <span className="mt-1 block">"{outfit.colorTip || 'Armoniza con tu paleta otoñal'}"</span>
                                       </p>
                                    </div>
                                  </motion.div>
                                )}
                              </AnimatePresence>
                            </motion.div>
                          ) : (
                            <button className="w-full h-[100px] border-[1.5px] border-dashed border-[#DDD] rounded-[14px] flex flex-col items-center justify-center gap-2 bg-[#FBFBFB] active:scale-[0.97] transition-all">
                               <Plus className="text-[#CCC]" size={20} />
                               <span className="text-[13px] font-medium text-[#BBB]">Registrar outfit</span>
                            </button>
                          )}
                        </motion.div>
                      );
                    })}
                 </div>

                 {/* Resumen del Día */}
                 {outfitsInDay.length > 0 && (
                   <motion.div 
                     initial={{ opacity: 0, y: 20 }}
                     animate={{ opacity: 1, y: 0 }}
                     transition={{ delay: 0.5 }}
                     className="bg-[#F8F8F6] rounded-[14px] p-4 mt-6 ml-11 border border-[#F0F0EE]"
                   >
                     <h4 className="mono text-[10px] text-[#BBB] uppercase font-bold tracking-widest mb-3">Resumen del día</h4>
                     <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[12px] font-medium text-estela-black">
                        <span>{outfitsInDay.length} outfits</span>
                        <span className="text-[#DDD]">·</span>
                        <span>{Array.from(new Set(outfitsInDay.flatMap(o => o.garments.map(g => g.name)))).length} prendas usadas</span>
                        <span className="text-[#DDD]">·</span>
                        <span>{Array.from(new Set(outfitsInDay.map(o => o.occasion))).length} categorías</span>
                     </div>
                     <div className="mt-3 flex items-center gap-2">
                        <span className="text-[11px] text-[#999]">Tu día:</span>
                        <span className="text-[14px]">
                          {outfitsInDay.map(o => {
                            if (o.id === 'ci-1' || o.id === 'ci-2') return '😍';
                            return '😊';
                          }).join('')}
                        </span>
                     </div>
                   </motion.div>
                 )}
                 
                 </div>
               </div>
            </motion.div>
          </AnimatePresence>
        </motion.div>
      );
    };

    return (
      <div className="flex-1 flex flex-col relative bg-white overflow-hidden h-full">
        <AnimatePresence mode="wait">
          {activeCalendarView === 'monthly' ? renderMonthlyView() : renderDailyView()}
        </AnimatePresence>
      </div>
    );
  };

  const renderGarmentModal = () => (
    <AnimatePresence>
      {isGarmentModalOpen && selectedGarment && (
        <div key="garment-modal-overlay" className="absolute inset-0 z-[1000] flex flex-col justify-end">
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }} 
            transition={{ duration: 0.2 }}
            onClick={() => setIsGarmentModalOpen(false)}
            className="absolute inset-0 bg-black/30 backdrop-blur-[4px]" 
          />
          <motion.div 
            initial={{ translateY: "100%" }} 
            animate={{ translateY: 0 }} 
            exit={{ translateY: "100%" }} 
            transition={{ duration: 0.3, ease: "easeOut" }}
            className="bg-white rounded-t-[20px] w-full max-h-[85vh] overflow-y-auto no-scrollbar relative z-[1001] pb-[32px]"
          >
            <div className="w-10 h-1 bg-[#DDD] rounded-full mx-auto mt-3 mb-4" />
            
            <div className="mx-5 mb-6">
              <div className="w-full h-[220px] rounded-[16px] flex items-center justify-center shadow-inner" style={{ background: selectedGarment.bgColor }}>
                 <div className={`shadow-md ${selectedGarment.category === 'Tops' ? 'w-[40%] h-[70%] rounded-t-[20px] rounded-b-[10px]' : selectedGarment.category === 'Bottoms' ? 'w-[25%] h-[90%] rounded-[10px]' : selectedGarment.category === 'Calzado' ? 'w-[60%] h-[30%] rounded-[12px]' : 'w-[40%] h-[40%] rounded-full'}`} style={{ backgroundColor: selectedGarment.mainColor }} />
              </div>
            </div>

            <div className="px-5 mb-6">
               <h2 className="serif text-[22px] mb-1">{selectedGarment.name}</h2>
               <p className="text-[12px] text-[#999] mb-1">{selectedGarment.material} · {selectedGarment.pattern} · Formalidad {[1,2,3,4,5].map(v => v <= selectedGarment.formality ? '★' : '☆')}</p>
               <p className="mono text-[11px] text-[#BBB]">Usada {selectedGarment.uses} veces · Última vez: {selectedGarment.lastWorn}</p>
            </div>

            <div className="px-5 space-y-6">
              <section>
                <h3 className="mono text-[10px] text-[#BBB] mb-3 uppercase">DETALLES</h3>
                <div className="flex flex-wrap gap-2">
                  <span className="px-[14px] py-[6px] rounded-full border border-[#DDD] text-[12px]">Top — {selectedGarment.category === 'Tops' ? 'Camisa' : selectedGarment.category}</span>
                  <span className="px-[14px] py-[6px] rounded-full border border-[#DDD] text-[12px]">{selectedGarment.material}</span>
                  <span className="px-[14px] py-[6px] rounded-full border border-[#DDD] text-[12px]">{selectedGarment.pattern}</span>
                  {["Primavera", "Verano", "Otoño", "Invierno"].map(s => {
                    const isSelected = selectedGarment.seasons.includes(s);
                    return <span key={s} className={`px-[14px] py-[6px] rounded-full border text-[12px] ${isSelected ? 'bg-black text-white border-black' : 'border-[#DDD] text-[#999]'}`}>{s}</span>
                  })}
                </div>
              </section>

              <section>
                 <h3 className="mono text-[10px] text-[#BBB] mb-3 uppercase">COLORES</h3>
                 <div className="flex gap-4">
                    {selectedGarment.dots.map(c => (
                      <div key={c} className="flex flex-col items-center gap-1.5">
                        <div className="w-6 h-6 rounded-full border border-black/5 shadow-sm" style={{ backgroundColor: c }} />
                        <span className="mono text-[9px] text-[#CCC]">{c}</span>
                      </div>
                    ))}
                 </div>
              </section>

              <section>
                 <h3 className="mono text-[10px] text-[#BBB] mb-3 uppercase">FORMALIDAD</h3>
                 <div className="flex items-center gap-4">
                    <span className="text-[10px] text-[#999]">Casual</span>
                    <div className="flex gap-1.5 flex-1">
                       {[1,2,3,4,5].map(v => <div key={v} className={`h-3 w-3 rounded-full flex-1 ${v <= selectedGarment.formality ? 'bg-black' : 'bg-[#E0E0E0]'}`} />)}
                    </div>
                    <span className="text-[10px] text-[#999]">Formal</span>
                 </div>
              </section>

              <section>
                 <h3 className="mono text-[10px] text-[#BBB] mb-3 uppercase">APARECE EN</h3>
                 <div className="scroll-hide flex gap-3 pb-2 overflow-x-auto">
                    {selectedGarment.outfitsWith.map((id: string) => {
                      const o = OUTFITS_DATA.find(x => x.id === id);
                      if (!o) return null;
                      return (
                        <div key={o.id} onClick={() => { setActiveScreen("home"); setIsGarmentModalOpen(false); }} className="w-[120px] shrink-0 cursor-pointer group">
                           <div className="aspect-square bg-[#F5F5F5] rounded-[12px] p-2 grid grid-cols-2 gap-1 group-active:scale-95 transition-transform">
                              {o.colors.map((c, i) => <div key={i} className="rounded-full border border-black/5" style={{ background: c }} />)}
                           </div>
                           <p className="text-[10px] font-semibold mt-2 truncate text-center">{o.name}</p>
                        </div>
                      )
                    })}
                 </div>
              </section>

              <div className="pt-4 space-y-4">
                <button onClick={() => { setActiveScreen("home"); setIsGarmentModalOpen(false); }} className="w-full h-[48px] bg-[#0A0A0A] text-white rounded-[14px] text-[14px] font-semibold active:scale-[0.98] transition-transform">Generar outfit con esta prenda →</button>
                <button className="w-full text-[#D32F2F] text-[13px] font-medium py-2">Eliminar prenda</button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );

  // --- RENDER ONBOARDING ---

  const renderOnboarding = () => {
    switch(step) {
      case 1: return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-white">
          <motion.h1 initial={{ opacity: 0, translateY: 10 }} animate={{ opacity: 1, translateY: 0 }} transition={{ duration: 0.8 }} className="serif text-[44px] tracking-[6px] mb-2">ESTELA</motion.h1>
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="text-[15px] text-[#999] mb-12">Descubramos tu estilo</motion.p>
          <button onClick={goNext} className="bg-estela-black text-white px-12 py-3.5 rounded-pill font-medium active:scale-95 shadow-lg">Comenzar</button>
        </motion.div>
      );
      case 2: return (
        <div className="h-full w-full flex flex-col p-6 overflow-y-auto no-scrollbar">
          <h2 className="serif text-2xl mb-1">Cuéntanos de ti</h2>
          <p className="text-[13px] text-[#999] mb-8">Esto nos ayuda a entender tu silueta y proporción</p>
          
          <div className="space-y-8">
            <section>
              <label className="mono block mb-4">Género expresivo</label>
              <div className="flex gap-3">
                {["Femenino", "Masculino", "Fluido"].map(g => (
                  <button key={g} onClick={() => setUser({...user, gender: g})} className={`flex-1 aspect-square rounded-[16px] flex flex-col items-center justify-center gap-2 border-2 transition-all ${user.gender === g ? 'border-estela-black scale-[1.02] bg-white' : 'border-transparent bg-[#F5F5F5]'}`}>
                    <div className="w-8 h-8 rounded-full border border-black/20" />
                    <span className="text-[12px] font-medium">{g}</span>
                  </button>
                ))}
              </div>
            </section>

            <section>
              <div className="flex justify-between items-end mb-4">
                <label className="mono">Estatura</label>
                <div className="flex items-baseline gap-1">
                  <span className="serif text-3xl font-bold">{user.height}</span>
                  <span className="mono text-[10px]">cm</span>
                </div>
              </div>
              <div className="relative h-8 flex items-center">
                <div className="absolute w-full h-0.5 bg-[#E5E5E5]" />
                <input type="range" min="140" max="200" value={user.height} onChange={e => setUser({...user, height: parseInt(e.target.value)})} className="absolute w-full opacity-0 cursor-pointer h-full z-10" />
                <div className="absolute h-5 w-5 bg-estela-black rounded-full shadow-lg pointer-events-none" style={{ left: `${((user.height - 140) / 60) * 100}%`, transform: 'translateX(-50%)' }} />
                <div className="w-full flex justify-between px-1 pointer-events-none mt-6">
                  {[140, 160, 180, 200].map(v => <div key={v} className="w-0.5 h-2 bg-[#E5E5E5]" />)}
                </div>
              </div>
            </section>

            <section className="flex items-center justify-between">
              <div>
                <label className="mono">¿Incluir peso?</label>
                <p className="text-[11px] text-[#999]">Ayuda a refinar proporciones</p>
              </div>
              <button onClick={() => setUser({...user, includeWeight: !user.includeWeight})} className={`w-12 h-7 rounded-full transition-colors flex items-center p-1 ${user.includeWeight ? 'bg-estela-black' : 'bg-[#DDD]'}`}>
                <div className={`w-5 h-5 bg-white rounded-full shadow transition-transform ${user.includeWeight ? 'translate-x-5' : 'translate-x-0'}`} />
              </button>
            </section>

            <section>
              <label className="mono block mb-4">Talla General</label>
              <div className="flex flex-wrap gap-2">
                {["XS", "S", "M", "L", "XL", "XXL"].map(s => (
                  <button key={s} onClick={() => setUser({...user, size: s})} className={`px-5 py-2 rounded-pill text-[13px] font-bold border transition-all ${user.size === s ? 'bg-estela-black text-white border-estela-black' : 'bg-white border-[#DDD] text-[#555]'}`}>{s}</button>
                ))}
              </div>
            </section>
          </div>
          <button onClick={goNext} className="bg-estela-black text-white w-full py-4 rounded-[14px] mt-12 mb-8 font-bold active:scale-95">Siguiente →</button>
        </div>
      );
      case 3: return (
        <div className="h-full w-full flex flex-col p-6 overflow-y-auto no-scrollbar">
          <h2 className="serif text-2xl mb-1">¿Cuál se parece más a tu silueta?</h2>
          <p className="text-[13px] text-[#999] mb-8">Esto nos ayuda a sugerirte cortes ideales</p>
          
          <button 
            onClick={() => startAnalysis('body')}
            className="mb-6 w-full py-4 rounded-[16px] border-2 border-estela-black bg-white flex items-center justify-center gap-3 font-bold active:scale-95 transition-all text-estela-black"
          >
            <Camera size={20} />
            Escanear mi cuerpo con IA
          </button>

          <div className="grid grid-cols-2 gap-4">
            {["Reloj de Arena", "Triángulo", "Triángulo Invertido", "Rectángulo", "Óvalo", "No estoy seguro/a"].map(t => (
              <button key={t} onClick={() => setUser({...user, bodyType: t})} className={`rounded-[16px] p-4 flex flex-col items-center gap-4 transition-all border-2 ${user.bodyType === t ? 'border-estela-black bg-white scale-[1.02]' : 'border-transparent bg-[#F5F5F5]'}`}>
                <div className="h-28 w-16"><BodyShapeSVG type={t} /></div>
                <span className="text-[12px] font-semibold text-center leading-tight">{t}</span>
              </button>
            ))}
          </div>
          <div className="mt-8 p-4 bg-[#F9F9F9] border-l-[3px] border-estela-black rounded-r-lg">
            <div className="flex justify-between items-center mb-1">
              <span className="text-[12px] font-bold">¿Por qué importa?</span>
              <Info size={14} className="text-estela-black" />
            </div>
            <p className="serif italic text-[13px] text-[#888] leading-tight">Tu tipo de cuerpo determina qué cortes y proporciones te favorecen.</p>
          </div>
          <button onClick={goNext} className="bg-estela-black text-white w-full py-4 rounded-[14px] mt-8 mb-8 font-bold shadow-lg shrink-0">Siguiente →</button>
        </div>
      );
      case 4: return (
        <div className="h-full w-full flex flex-col p-6 overflow-y-auto no-scrollbar">
          <h2 className="serif text-2xl mb-1">¿Qué forma tiene tu rostro?</h2>
          <p className="text-[13px] text-[#999] mb-8">Esto nos ayuda con accesorios y cuellos</p>
          
          <button 
            onClick={() => startAnalysis('face')}
            className="mb-6 w-full py-4 rounded-[16px] border-2 border-estela-black bg-white flex items-center justify-center gap-3 font-bold active:scale-95 transition-all text-estela-black"
          >
            <Camera size={20} />
            Escanear mi rostro con IA
          </button>

          <div className="grid grid-cols-2 gap-4 mb-8">
            {Object.keys(FACE_SHAPES).map(t => (
              <button key={t} onClick={() => setUser({...user, faceShape: t})} className={`rounded-[16px] p-6 flex flex-col items-center gap-4 transition-all border-2 px-1 ${user.faceShape === t ? 'border-estela-black bg-white scale-[1.02]' : 'border-transparent bg-[#F5F5F5]'}`}>
                <div className="w-12 h-12"><FaceShapeSVG type={t} /></div>
                <span className="text-[12px] font-semibold">{t}</span>
              </button>
            ))}
          </div>
          <AnimatePresence mode="wait">
            <motion.div key={user.faceShape} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="p-4 bg-[#F9F9F9] border-l-[3px] border-estela-black rounded-r-lg min-h-[80px]">
              <p className="serif italic text-[13px] text-estela-black leading-tight">
                {user.faceShape === "Ovalada" && "La forma más versátil — te van casi todos los cuellos y accesorios."}
                {user.faceShape === "No estoy seguro/a" ? "Escanéate arriba para una detección precisa." : ""}
                {user.faceShape === "Redonda" && "Te favorecen cuellos en V y accesorios largos que alarguen visualmente."}
                {user.faceShape === "Cuadrada" && "Los cuellos redondos y bufandas suaves suavizan los ángulos."}
                {user.faceShape === "Corazón" && "Cuellos boat-neck y aretes tipo chandelier equilibran la proporción."}
                {user.faceShape === "Alargada" && "Cuellos crew y turtleneck aportan horizontalidad."}
                {user.faceShape === "Diamante" && "Cuellos off-shoulder y aretes sutiles resaltan tus pómulos."}
              </p>
            </motion.div>
          </AnimatePresence>
          <button onClick={goNext} className="bg-estela-black text-white w-full py-4 rounded-[14px] mt-12 mb-8 font-bold shrink-0">Siguiente →</button>
        </div>
      );
      case 5: return (
        <div className="h-full w-full flex flex-col p-6 overflow-y-auto no-scrollbar">
          <h2 className="serif text-2xl mb-1">Descubramos tus colores</h2>
          <p className="text-[13px] text-[#999] mb-8">Tu paleta personal para que cada outfit te ilumine</p>
          
          <section className="mb-10">
            <p className="mono mb-4">¿Cómo describirías tu tono de piel?</p>
            <div className="flex gap-3">
              {[
                { n: "Cálido", g: "from-[#F5D0A9] to-[#FAEBD7]" },
                { n: "Frío", g: "from-[#E8D0E8] to-[#F0E6F6]" },
                { n: "Neutro", g: "from-[#EDE8E0] to-[#F0EEEB]" }
              ].map(t => (
                <button key={t.n} onClick={() => setUser({...user, skinTone: t.n})} className={`flex-1 flex flex-col items-center gap-2 border-2 p-1.5 rounded-[14px] transition-all ${user.skinTone === t.n ? 'border-estela-black scale-[1.02]' : 'border-transparent'}`}>
                  <div className={`w-full aspect-square rounded-[10px] bg-gradient-to-br ${t.g}`} />
                  <span className="text-[11px] font-bold">{t.n}</span>
                </button>
              ))}
            </div>
          </section>

          <section>
            <p className="mono mb-4">Estación de color</p>
            <div className="grid grid-cols-1 gap-4">
              {(user.skinTone === "Cálido" ? ["Primavera", "Otoño"] : (user.skinTone === "Frío" ? ["Verano", "Invierno"] : ["Primavera", "Otoño", "Verano", "Invierno"])).map(st => (
                <button key={st} onClick={() => setUser({...user, station: st})} className={`p-4 rounded-[16px] text-left border-2 transition-all ${user.station === st ? 'border-estela-black scale-[1.02] bg-white shadow-md' : 'border-transparent bg-[#F5F5F5]'}`}>
                  <div className="flex justify-between items-center mb-3">
                    <span className="serif text-lg">{st}</span>
                    <span className="mono text-[9px] text-estela-light-gray">{st === "Primavera" || st === "Otoño" ? 'cálido' : 'frío'} · vibrante</span>
                  </div>
                  <div className="flex gap-2">
                    {PALETAS[st as keyof typeof PALETAS].slice(0, 5).map(c => <div key={c} className="w-6 h-6 rounded-full" style={{ background: c }} />)}
                  </div>
                </button>
              ))}
            </div>
          </section>

          <div className="mt-12 p-6 border border-estela-border rounded-[20px] bg-white shadow-sm">
            <h3 className="serif text-xl mb-4 text-center">Tu paleta personal</h3>
            <div className="grid grid-cols-4 gap-3">
              {PALETAS[user.station as keyof typeof PALETAS].map(c => (
                <div key={c} className="flex flex-col items-center gap-1">
                  <div className="w-10 h-10 rounded-full shadow-inner" style={{ background: c }} />
                  <span className="mono text-[8px] text-[#999]">{c}</span>
                </div>
              ))}
            </div>
          </div>
          <button onClick={goNext} className="bg-estela-black text-white w-full py-4 rounded-[14px] mt-12 mb-8 font-bold">Siguiente →</button>
        </div>
      );
      case 6: return (
        <div className="h-full w-full flex flex-col p-6 overflow-y-auto no-scrollbar">
          <h2 className="serif text-2xl mb-1">¿Qué estéticas te atraen?</h2>
          <p className="text-[13px] text-[#999] mb-8">Selecciona de 1 a 3</p>
          <div className="grid grid-cols-2 gap-4">
            {ESTETICAS.map(e => {
              const isActive = user.estilos.includes(e.name);
              return (
                <button key={e.name} onClick={() => {
                  if (isActive) setUser({...user, estilos: user.estilos.filter(x => x !== e.name)})
                  else if (user.estilos.length < 3) setUser({...user, estilos: [...user.estilos, e.name]})
                }} className={`relative rounded-[16px] overflow-hidden border-2 transition-all group ${isActive ? 'border-estela-black scale-[1.02]' : 'border-transparent bg-white shadow-sm'}`}>
                  <div className={`aspect-[3/4] bg-gradient-to-br ${e.gradient} opacity-80`} />
                  <div className="absolute inset-0 flex flex-col justify-end p-3 bg-gradient-to-t from-white/90 to-transparent">
                    <span className="text-[14px] font-bold">{e.name}</span>
                    <span className="text-[10px] text-estela-gray leading-tight mt-1 line-clamp-2">{e.desc}</span>
                  </div>
                  {isActive && <div className="absolute top-3 right-3 w-6 h-6 bg-estela-black text-white rounded-full flex items-center justify-center shadow-lg"><Check size={14} strokeWidth={3} /></div>}
                </button>
              );
            })}
          </div>
          <button onClick={goNext} className="bg-estela-black text-white w-full py-4 rounded-[14px] mt-12 mb-8 font-bold disabled:opacity-30" disabled={user.estilos.length === 0}>Siguiente →</button>
        </div>
      );
      case 7: return (
        <div className="h-full w-full flex flex-col p-6 overflow-y-auto no-scrollbar">
          <h2 className="serif text-2xl mb-1 mt-8">Ahora, tu armario</h2>
          <p className="text-[13px] text-[#999] mb-8">Sube al menos 5 prendas para tu primer outfit</p>
          <div onClick={() => setUser({...user, itemsCount: Math.min(5, user.itemsCount + 1)})} className="border-[1.5px] border-dashed border-[#CCC] rounded-[16px] p-12 flex flex-col items-center justify-center text-center gap-3 bg-white hover:bg-[#F9F9F9] transition-colors cursor-pointer">
            <Camera size={32} className="text-[#999]" />
            <p className="text-[14px] text-[#999] font-medium">Toca para añadir fotos</p>
          </div>
          <div className="mt-8">
            <div className="scroll-hide flex gap-3 pb-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className={`w-14 h-14 rounded-[10px] flex-shrink-0 animate-pulse-slow ${i < user.itemsCount ? 'bg-estela-black/10 flex items-center justify-center' : 'bg-[#F2F2F2]'}`}>
                  {i < user.itemsCount && <Check size={20} className="text-estela-black/40" />}
                </div>
              ))}
            </div>
            <div className="flex justify-between items-center mt-2 px-1">
              <span className="mono text-[10px] text-estela-black font-bold">{user.itemsCount}/5 prendas</span>
              <span className="text-[12px] italic text-[#999]">{user.itemsCount < 3 ? 'Vamos...' : user.itemsCount < 5 ? '¡Casi listo!' : '¡Perfecto!'}</span>
            </div>
          </div>
          <button 
            onClick={() => { setShowReveal(true); setTimeout(() => { setShowReveal(false); setStep(8); }, 2200); }} 
            className="bg-estela-black text-white w-full py-4 rounded-[14px] mt-auto mb-8 font-bold disabled:opacity-30 flex items-center justify-center gap-2" 
            disabled={user.itemsCount < 5}
          >
            Ver mi Style DNA <ChevronRight size={18} />
          </button>
        </div>
      );
      case 8: return (
        <div className="h-full w-full flex flex-col bg-white">
          <div className="flex-1 overflow-y-auto no-scrollbar p-6">
            <div className="text-center mt-8 mb-10">
              <h1 className="serif text-3xl mb-1">Tu Style DNA</h1>
              <p className="text-[13px] text-[#999]">Personalizado para ti</p>
            </div>

            <div className="space-y-4 pb-24">
              <div className="bg-white border border-estela-border rounded-[16px] p-4 flex items-center gap-5 shadow-sm">
                <div className="w-16 h-24 shrink-0 bg-[#F5F5F5] rounded-[10px] p-3"><BodyShapeSVG type={user.bodyType} /></div>
                <div>
                   <p className="text-[15px] font-bold">Tipo: {user.bodyType}</p>
                   <p className="serif italic text-[13px] text-estela-gray mt-1 leading-tight">Proporciones equilibradas. Te recomendaremos prendas que marquen tu silueta natural.</p>
                </div>
              </div>

              <div className="bg-white border border-estela-border rounded-[16px] p-4 flex items-center gap-5 shadow-sm">
                <div className="w-16 h-16 shrink-0 bg-[#F5F5F5] rounded-full p-4"><FaceShapeSVG type={user.faceShape} /></div>
                <div>
                   <p className="text-[15px] font-bold">Rostro: {user.faceShape}</p>
                   <p className="serif italic text-[13px] text-estela-gray mt-1 leading-tight">Forma armoniosa. Ideal para cuellos V y accesorios que alargan visualmente.</p>
                </div>
              </div>

              <div className="bg-[#F9F9F7] rounded-[16px] p-5 shadow-sm">
                 <div className="flex justify-between items-center mb-4">
                    <span className="serif text-lg">Estación: {user.station}</span>
                    <span className="mono text-[9px] text-estela-light-gray">{user.skinTone}</span>
                 </div>
                 <div className="grid grid-cols-8 gap-2 mb-4">
                    {PALETAS[user.station as keyof typeof PALETAS].map(c => <div key={c} className="w-6 h-6 rounded-full" style={{ background: c }} />)}
                 </div>
                 <p className="text-[12px] text-estela-gray leading-snug">Priorizaremos prendas en {PALETAS[user.station as keyof typeof PALETAS].slice(0,3).join(', ')} para iluminar tu rostro.</p>
              </div>

              <div className="flex flex-wrap gap-2 pt-2">
                 {user.estilos.map(e => <span key={e} className="px-5 py-2 rounded-pill bg-estela-black text-white text-[12px] font-bold uppercase tracking-wider">{e}</span>)}
              </div>

              <button onClick={() => setStep(9)} className="bg-estela-black text-white w-full py-4 rounded-[16px] font-bold flex items-center justify-center gap-2 shadow-xl active:scale-95">Descubrir mis outfits →</button>
            </div>
          </div>
        </div>
      );
      case 9: return (
        <div className="h-full w-full flex flex-col bg-[#FAFAFA] relative overflow-hidden">
          <AnimatePresence mode="wait">
            {activeScreen === "home" && (
              <motion.div key="home" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }} className="flex-1 overflow-y-auto no-scrollbar pb-24">
                {renderHomeScreen()}
              </motion.div>
            )}
            {activeScreen === "closet" && (
              <motion.div key="closet" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }} className="flex-1 overflow-y-auto no-scrollbar pb-24">
                {renderClosetScreen()}
              </motion.div>
            )}
            {activeScreen === "add" && (
              <motion.div key="add" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }} className="flex-1 flex flex-col overflow-hidden">
                {renderAddGarmentScreen()}
              </motion.div>
            )}
            {activeScreen === "calendar" && (
              <motion.div key="calendar" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }} className="flex-1 flex flex-col min-h-0">
                {renderCalendarScreen()}
              </motion.div>
            )}
            {activeScreen === "profile" && (
              <motion.div key="profile" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }} className="flex-1 flex flex-col items-center justify-center text-center p-6 bg-white">
                <div className="w-24 h-24 bg-[#F5F5F5] rounded-full flex items-center justify-center mb-6">
                  <UserCircle size={48} className="text-[#CCC]" />
                </div>
                <h2 className="serif text-[24px] mb-2">Próximamente</h2>
                <p className="text-[13px] text-[#999]">Estamos trabajando en esto para ti</p>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Bottom Navigation */}
          <nav className="absolute bottom-0 left-0 right-0 h-[72px] border-t border-estela-border bg-white shadow-lg flex items-center justify-around px-2 z-[500] pointer-events-auto">
            <button onClick={() => setActiveScreen("home")} className="flex flex-col items-center justify-center gap-1 min-w-[60px]">
              <LayoutGrid size={22} className={activeScreen === "home" ? "text-estela-black" : "text-[#AAA] opacity-40"} fill={activeScreen === "home" ? "currentColor" : "none"} />
              {activeScreen === "home" && <span className="mono text-[9px] font-bold uppercase">Home</span>}
            </button>
            <button onClick={() => setActiveScreen("closet")} className="flex flex-col items-center justify-center gap-1 min-w-[60px]">
              <Shirt size={22} className={activeScreen === "closet" ? "text-estela-black" : "text-[#AAA] opacity-40"} fill={activeScreen === "closet" ? "currentColor" : "none"} />
              {activeScreen === "closet" && <span className="mono text-[9px] font-bold uppercase">Armario</span>}
            </button>
            <button onClick={() => { setActiveScreen("add"); setAddGarmentStep(1); }} className="relative -mt-8 flex flex-col items-center gap-1">
              <div className="w-14 h-14 bg-estela-black rounded-full flex items-center justify-center shadow-xl border-4 border-white active:scale-90 transition-transform">
                <Plus color="white" size={26} strokeWidth={2.5} />
              </div>
            </button>
            <button onClick={() => setActiveScreen("calendar")} className="flex flex-col items-center justify-center gap-1 min-w-[60px]">
              <CalendarIcon size={22} className={activeScreen === "calendar" ? "text-estela-black" : "text-[#AAA] opacity-40"} fill={activeScreen === "calendar" ? "currentColor" : "none"} />
              {activeScreen === "calendar" && <span className="mono text-[9px] font-bold uppercase">Agenda</span>}
            </button>
            <button onClick={() => setActiveScreen("profile")} className="flex flex-col items-center justify-center gap-1 min-w-[60px]">
              <UserCircle size={22} className={activeScreen === "profile" ? "text-estela-black" : "text-[#AAA] opacity-40"} fill={activeScreen === "profile" ? "currentColor" : "none"} />
              {activeScreen === "profile" && <span className="mono text-[9px] font-bold uppercase">Perfil</span>}
            </button>
          </nav>

          {/* Garment Detail Modal Trigger */}
          {renderGarmentModal()}
        </div>
      );
      default: return null;
    }
  };

  // --- REVEAL ANIMATION OVERLAY ---
  if (showReveal) {
    return (
      <div className="phone-view-container">
        <div className="phone-frame">
          <div className="phone-notch" />
          <div className="iphone-frame desktop-frame overflow-hidden bg-[#FAFAFA] h-full">
            <motion.div initial={{ backgroundColor: "#FAFAFA" }} animate={{ backgroundColor: ["#FAFAFA", "#0A0A0A", "#FAFAFA"], transition: { duration: 2.2, times: [0, 0.4, 1] } }} className="absolute inset-0 flex items-center justify-center z-[1000]">
               <motion.h1 initial={{ opacity: 0 }} animate={{ opacity: [0, 1, 0], scale: [0.9, 1.1, 1], transition: { duration: 1.8, times: [0, 0.4, 0.8] } }} className="serif text-white text-4xl tracking-[10px]">ESTELA</motion.h1>
            </motion.div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="phone-view-container">
      <div className="phone-frame">
        <div className="phone-notch" />
        <div className="iphone-frame desktop-frame overflow-hidden flex flex-col bg-[#FAFAFA] relative h-full">
          {step < 9 && <StepHeader step={step} onBack={goBack} />}
      
      {/* AI Analysis Sub-flow Overlay */}
      <AnimatePresence>
        {analysis.active && (
          <motion.div 
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="absolute inset-0 z-[1100] bg-white flex flex-col"
          >
            <div className="px-6 pt-12 flex justify-between items-center bg-white z-10">
              <IconButton icon={X} onClick={closeAnalysis} />
              <span className="mono text-[11px] font-bold">Detección IA</span>
              <div className="w-10" />
            </div>

            {analysis.step === 'camera' && (
              <div className="flex-1 flex flex-col p-6">
                <h3 className="serif text-[24px] mb-6 mt-4">Analiza tu {analysis.type === 'body' ? 'silueta' : 'rostro'}</h3>
                <div className="flex-1 bg-[#1A1A1A] rounded-[24px] relative overflow-hidden flex flex-col items-center justify-center">
                  <div className="absolute inset-8 border border-white/30 rounded-[20px] pointer-events-none" />
                  <Camera size={48} className="text-white/20" />
                  <div className="absolute bottom-8 left-0 right-0 flex justify-center">
                     <button onClick={captureAnalysis} className="w-16 h-16 rounded-full border-4 border-white flex items-center justify-center">
                        <div className="w-12 h-12 bg-white rounded-full" />
                     </button>
                  </div>
                </div>
                <p className="text-[13px] text-center text-[#999] mt-6 px-4">Ubícate en un lugar iluminado y mantén la cámara estable.</p>
              </div>
            )}

            {analysis.step === 'processing' && (
              <div className="flex-1 flex flex-col items-center justify-center gap-6">
                <div className="relative">
                  <div className="w-24 h-24 rounded-full border-4 border-[#F0F0F0] border-t-estela-black animate-spin" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <LayoutGrid size={24} className="text-estela-black animate-pulse" />
                  </div>
                </div>
                <div className="text-center">
                  <h3 className="serif text-xl mb-2">Analizando proporciones</h3>
                  <p className="text-[13px] text-[#999] px-12">Nuestra IA está midiendo puntos clave para determinar tu {analysis.type === 'body' ? 'silueta' : 'forma de cara'}...</p>
                </div>
              </div>
            )}

            {analysis.step === 'result' && (
              <div className="flex-1 flex flex-col p-6 animate-fade-in">
                <div className="flex-1 flex flex-col items-center justify-center">
                  <div className="w-48 h-64 bg-[#F5F5F5] rounded-[24px] flex items-center justify-center p-8 mb-8 shadow-inner">
                    {analysis.type === 'body' ? <BodyShapeSVG type={analysis.result!} /> : <FaceShapeSVG type={analysis.result!} />}
                  </div>
                  <h3 className="serif text-[28px] mb-2">¡Detectado!</h3>
                  <p className="text-[16px] font-bold text-estela-black mb-4">Tienes un {analysis.type === 'body' ? 'tipo de cuerpo' : 'rostro'} {analysis.result}</p>
                  
                  <div className="bg-[#F9F9F9] p-5 rounded-[16px] border border-black/5 mx-4">
                    <p className="serif italic text-[14px] text-center text-estela-gray leading-tight">
                      {analysis.type === 'body' 
                        ? "Tu silueta presenta hombros y caderas equilibrados con una cintura definida. Te van genial las prendas entalladas."
                        : "Tu rostro ovalado es extremadamente balanceado. Te favorece casi cualquier tipo de cuello y accesorio."}
                    </p>
                  </div>
                </div>
                <button onClick={closeAnalysis} className="bg-estela-black text-white w-full py-4 rounded-[16px] font-bold shadow-lg mb-4">Continuar</button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex-1 overflow-hidden relative min-h-0">
        <AnimatePresence mode="wait">
          <motion.div 
            key={step} 
            initial={{ opacity: 0, x: 20 }} 
            animate={{ opacity: 1, x: 0 }} 
            exit={{ opacity: 0, x: -20 }} 
            transition={{ duration: 0.3 }} 
            className="h-full w-full flex flex-col"
          >
            {renderOnboarding()}
          </motion.div>
        </AnimatePresence>
      </div>
      </div>
      </div>
    </div>
  );
}
